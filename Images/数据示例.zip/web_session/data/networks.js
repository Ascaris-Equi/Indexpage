var networks = {"Sheet1": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "Sheet1",
    "name" : "Sheet1",
    "SUID" : 61,
    "__Annotations" : [ "" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "230",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SpkB",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "SpkB",
        "SelfLoops" : 0,
        "SUID" : 230,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -1073.8961633683487,
        "y" : -175.27094522257175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pliA",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pliA",
        "SelfLoops" : 0,
        "SUID" : 229,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -168.1188502646413,
        "y" : 1523.3343143354805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SpkA ",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "SpkA ",
        "SelfLoops" : 0,
        "SUID" : 228,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -648.1188502646413,
        "y" : 1203.3343143354805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ndnblA2",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ndnblA2",
        "SelfLoops" : 0,
        "SUID" : 227,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1018.3013646570502,
        "y" : -94.77126067106815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nblA1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "nblA1",
        "SelfLoops" : 0,
        "SUID" : 226,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1023.8578731937681,
        "y" : -63.25873482622842
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pgr5",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pgr5",
        "SelfLoops" : 0,
        "SUID" : 225,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1028.4117569395794,
        "y" : -31.585777669215986
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hli",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "hli",
        "SelfLoops" : 0,
        "SUID" : 224,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1031.9584305195676,
        "y" : 0.21571881691374983
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ndhD2",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ndhD2",
        "SelfLoops" : 0,
        "SUID" : 223,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1034.4943227340768,
        "y" : 32.11373322089662
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sll0967和sll0939",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "sll0967和sll0939",
        "SelfLoops" : 0,
        "SUID" : 222,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 637.3088852069765,
        "y" : 191.74484113430253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pH",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pH",
        "SelfLoops" : 0,
        "SUID" : 221,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -748.1188502646413,
        "y" : 1203.3343143354805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik14-Rre8",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "Hik14-Rre8",
        "SelfLoops" : 0,
        "SUID" : 220,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -1148.1188502646414,
        "y" : 1203.3343143354805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Ni2+转运",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Ni2+转运",
        "SelfLoops" : 0,
        "SUID" : 219,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -119.44695381100712,
        "y" : -1052.7103686971166
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 205,
        "shared_name" : "nrsBACD",
        "BetweennessCentrality" : 0.009050772626931568,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "nrsBACD",
        "SelfLoops" : 0,
        "SUID" : 218,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.5
      },
      "position" : {
        "x" : -113.74095691731827,
        "y" : -980.9368248285768
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Cu2+",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Cu2+",
        "SelfLoops" : 0,
        "SUID" : 217,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 1043.5948029341102,
        "y" : -40.700434326525965
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "碱�?�磷酸酶",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "碱�?�磷酸酶",
        "SelfLoops" : 0,
        "SUID" : 216,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 111.88114973535869,
        "y" : 1203.3343143354805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik7-Rre29",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "Hik7-Rre29",
        "SelfLoops" : 0,
        "SUID" : 215,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 271.8811497353587,
        "y" : 1443.3343143354805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KDP",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KDP",
        "SelfLoops" : 0,
        "SUID" : 214,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 23.28892373277654,
        "y" : -983.1112096541351
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "slr1963",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "slr1963",
        "SelfLoops" : 0,
        "SUID" : 213,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 979.7791796253185,
        "y" : 128.0654061564153
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "groESL1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "groESL1",
        "SelfLoops" : 0,
        "SUID" : 212,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 980.2868691656055,
        "y" : 96.07077655126136
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "htpG",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "htpG",
        "SelfLoops" : 0,
        "SUID" : 211,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 978.2566222047902,
        "y" : 160.02781988162542
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hliB",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "hliB",
        "SelfLoops" : 0,
        "SUID" : 210,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -68.11885026464131,
        "y" : 1283.3343143354805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre26",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "Rre26",
        "SelfLoops" : 0,
        "SUID" : 209,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 11.88114973535869,
        "y" : 1203.3343143354805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : " Ssl3451",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : " Ssl3451",
        "SelfLoops" : 0,
        "SUID" : 208,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1036.0168801546054,
        "y" : 64.07614694610652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "desB",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "desB",
        "SelfLoops" : 0,
        "SUID" : 207,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.5
      },
      "position" : {
        "x" : 374.75783402659647,
        "y" : 634.2510205432018
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "icfG",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "icfG",
        "SelfLoops" : 0,
        "SUID" : 206,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 978.2566222047902,
        "y" : 32.11373322089685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "葡萄糖激�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "葡萄糖激�?",
        "SelfLoops" : 0,
        "SUID" : 205,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 975.720729990281,
        "y" : 0.2157188169139772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "异养生长",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "异养生长",
        "SelfLoops" : 0,
        "SUID" : 204,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 653.1338576554728,
        "y" : 934.6238556876403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 92,
        "shared_name" : "Sll1334",
        "BetweennessCentrality" : 0.004061810154525386,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "Sll1334",
        "SelfLoops" : 0,
        "SUID" : 203,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.5
      },
      "position" : {
        "x" : 607.7340656253872,
        "y" : 878.7413102586338
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "趋光运动",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 3,
        "name" : "趋光运动",
        "SelfLoops" : 0,
        "SUID" : 202,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -350.3037964244152,
        "y" : 686.1084518201824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "黑暗",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "黑暗",
        "SelfLoops" : 0,
        "SUID" : 201,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 764.5415862498311,
        "y" : 719.4258337733236
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "ClosenessCentrality" : 0.5294117647058824,
        "Eccentricity" : 3,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "细胞生长",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "细胞生长",
        "SelfLoops" : 0,
        "SUID" : 200,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8888888888888888,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 479.949278559233,
        "y" : 536.3143162450685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik47-Slr6041",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 3,
        "name" : "Hik47-Slr6041",
        "SelfLoops" : 0,
        "SUID" : 199,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.333333333333333
      },
      "position" : {
        "x" : 510.06139372730183,
        "y" : 498.9474608424946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Gap1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Gap1",
        "SelfLoops" : 0,
        "SUID" : 198,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 802.4813254099553,
        "y" : -475.7556334272952
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "ClosenessCentrality" : 0.5454545454545455,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "光激活异养生�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "光激活异养生�?",
        "SelfLoops" : 0,
        "SUID" : 197,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8333333333333333,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 744.364747514294,
        "y" : -552.1199254355436
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "杂合组氨酸激�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 18,
        "Indegree" : 18,
        "name" : "杂合组氨酸激�?",
        "SelfLoops" : 0,
        "SUID" : 196,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -658.0024912702162,
        "y" : 331.0052281804137
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "仅传感器组氨酸激�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 28,
        "Indegree" : 28,
        "name" : "仅传感器组氨酸激�?",
        "SelfLoops" : 0,
        "SUID" : 195,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.714285714285714
      },
      "position" : {
        "x" : 583.3998875301894,
        "y" : 375.3420265834518
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 3,
        "shared_name" : "spkL-Sll0095",
        "BetweennessCentrality" : 1.3641064002992232E-5,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "spkL-Sll0095",
        "SelfLoops" : 0,
        "SUID" : 194,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : -593.66876626322,
        "y" : -267.3860851018528
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 3,
        "shared_name" : "SpkJ-Slr0889",
        "BetweennessCentrality" : 1.3641064002992232E-5,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "SpkJ-Slr0889",
        "SelfLoops" : 0,
        "SUID" : 193,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : -566.2990942565855,
        "y" : -306.80590773997665
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 3,
        "shared_name" : "SpkI-Sll1770",
        "BetweennessCentrality" : 1.998373416986174E-5,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "SpkI-Sll1770",
        "SelfLoops" : 0,
        "SUID" : 192,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -536.1869790885164,
        "y" : -344.17276314255014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 3,
        "shared_name" : "SpkH-Sll0005",
        "BetweennessCentrality" : 1.3641064002992232E-5,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "SpkH-Sll0005",
        "SelfLoops" : 0,
        "SUID" : 191,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : -503.4858651955949,
        "y" : -379.29623837969143
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "膜蛋�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 19,
        "Indegree" : 19,
        "name" : "膜蛋�?",
        "SelfLoops" : 0,
        "SUID" : 190,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.2631578947368425
      },
      "position" : {
        "x" : 616.9199512993558,
        "y" : 285.4712576636591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "可溶性蛋�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 43,
        "Indegree" : 43,
        "name" : "可溶性蛋�?",
        "SelfLoops" : 0,
        "SUID" : 189,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.186046511627907
      },
      "position" : {
        "x" : 294.0660958951304,
        "y" : 686.1084518201812
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 6,
        "shared_name" : "SpkK-Slr1919 ",
        "BetweennessCentrality" : 6.413384454513769E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "SpkK-Slr1919 ",
        "SelfLoops" : 0,
        "SUID" : 188,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.666666666666666
      },
      "position" : {
        "x" : -673.1576518286405,
        "y" : -93.32970456114344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 6,
        "shared_name" : "spkF-Slr1225",
        "BetweennessCentrality" : 6.413384454513769E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "spkF-Slr1225",
        "SelfLoops" : 0,
        "SUID" : 187,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.666666666666666
      },
      "position" : {
        "x" : -658.0024912702154,
        "y" : -138.86367507789328
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "GroES (in vitro assay)",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 3,
        "name" : "GroES (in vitro assay)",
        "SelfLoops" : 0,
        "SUID" : 186,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -618.1565255335646,
        "y" : -226.1141696085108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 6,
        "shared_name" : "spkC-Slr0599",
        "BetweennessCentrality" : 6.413384454513769E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "spkC-Slr0599",
        "SelfLoops" : 0,
        "SUID" : 185,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.666666666666666
      },
      "position" : {
        "x" : -639.6375880594736,
        "y" : -183.20047348093522
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "GlyS",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "GlyS",
        "SelfLoops" : 0,
        "SUID" : 184,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -1004.203856867811,
        "y" : -157.1882901455341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "高盐",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "高盐",
        "SelfLoops" : 0,
        "SUID" : 183,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -638.8191225166302,
        "y" : -706.3800147443715
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "低温",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "低温",
        "SelfLoops" : 0,
        "SUID" : 182,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -613.0515554712741,
        "y" : -725.3522724066377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "181",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 6,
        "shared_name" : "spkE-Slr1443",
        "BetweennessCentrality" : 1.4609139512882004E-4,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "spkE-Slr1443",
        "SelfLoops" : 0,
        "SUID" : 181,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -430.9955345558799,
        "y" : -442.10946744068184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "180",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TCA循环代谢�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "TCA循环代谢�?",
        "SelfLoops" : 0,
        "SUID" : 180,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -532.321709979768,
        "y" : -777.2341937968574
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "高盐条件下的生长缺陷",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "高盐条件下的生长缺陷",
        "SelfLoops" : 0,
        "SUID" : 179,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -663.9717661546734,
        "y" : -686.599757156112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 9,
        "shared_name" : "spkG-Slr0152",
        "BetweennessCentrality" : 2.785417262546478E-4,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "spkG-Slr0152",
        "SelfLoops" : 0,
        "SUID" : 178,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.5
      },
      "position" : {
        "x" : -468.36238995845355,
        "y" : -411.99735227261283
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "低无机碳条件下的生长缺陷",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "低无机碳条件下的生长缺陷",
        "SelfLoops" : 0,
        "SUID" : 177,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -559.7760272323615,
        "y" : -760.7972069551563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 9,
        "shared_name" : "spkD-Sll0776",
        "BetweennessCentrality" : 2.848843964215174E-4,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "spkD-Sll0776",
        "SelfLoops" : 0,
        "SUID" : 176,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.5
      },
      "position" : {
        "x" : -391.57571191775605,
        "y" : -469.4791394473164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "175",
        "ClosenessCentrality" : 0.3918918918918919,
        "Eccentricity" : 3,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 68,
        "shared_name" : "SpkB-Slr1697",
        "BetweennessCentrality" : 0.002463972189830807,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "SpkB-Slr1697",
        "SelfLoops" : 0,
        "SUID" : 175,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.5517241379310347,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.2
      },
      "position" : {
        "x" : -685.0258425104165,
        "y" : -46.83059260711889
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "174",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "运动性缺�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "运动性缺�?",
        "SelfLoops" : 0,
        "SUID" : 174,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -350.30379642441403,
        "y" : -493.96689871766074
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "173",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 6,
        "shared_name" : "SpkA-Sll1574&1575",
        "BetweennessCentrality" : 7.986622956590613E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "SpkA-Sll1574&1575",
        "SelfLoops" : 0,
        "SUID" : 173,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.333333333333332
      },
      "position" : {
        "x" : -307.3901002968385,
        "y" : -515.4479612435698
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "172",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "黑暗中的成长优势",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "黑暗中的成长优势",
        "SelfLoops" : 0,
        "SUID" : 172,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 895.6901578282783,
        "y" : -308.22986844700006
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "171",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "非运动�?�的",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "非运动�?�的",
        "SelfLoops" : 0,
        "SUID" : 171,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -217.51933137704697,
        "y" : 741.1095781152585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "170",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "抑制的光自养生长",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "抑制的光自养生长",
        "SelfLoops" : 0,
        "SUID" : 170,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1036.5245696948923,
        "y" : 96.07077655126045
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "169",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "分割缺陷",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "分割缺陷",
        "SelfLoops" : 0,
        "SUID" : 169,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.5
      },
      "position" : {
        "x" : 447.2481646663115,
        "y" : 571.4377914822103
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "负趋光�??",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "负趋光�??",
        "SelfLoops" : 0,
        "SUID" : 168,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -475.91816222432243,
        "y" : 999.5960231205399
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "167",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "�?定条件下的生长缺�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "�?定条件下的生长缺�?",
        "SelfLoops" : 0,
        "SUID" : 167,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -938.6351356982277,
        "y" : 529.4784240840027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "细胞生存的必�?�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "细胞生存的必�?�?",
        "SelfLoops" : 0,
        "SUID" : 166,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.5
      },
      "position" : {
        "x" : 67.55521431840464,
        "y" : -569.3569589203578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "光敏感：葡萄糖暗循环",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "光敏感：葡萄糖暗循环",
        "SelfLoops" : 0,
        "SUID" : 165,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 783.9202831167457,
        "y" : -501.82097020298255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "164",
        "ClosenessCentrality" : 0.52,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "渗�?�压",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "渗�?�压",
        "SelfLoops" : 0,
        "SUID" : 164,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9230769230769231,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1031.9584305195679,
        "y" : 191.92583428560738
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "ClosenessCentrality" : 0.5294117647058824,
        "Eccentricity" : 3,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "暗循�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "暗循�?",
        "SelfLoops" : 0,
        "SUID" : 163,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8888888888888888,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.5
      },
      "position" : {
        "x" : 642.4387612225404,
        "y" : 48.11154964620232
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "162",
        "ClosenessCentrality" : 0.5365853658536586,
        "Eccentricity" : 3,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "碳源",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "碳源",
        "SelfLoops" : 0,
        "SUID" : 162,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8636363636363635,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.5
      },
      "position" : {
        "x" : 412.1246894291702,
        "y" : 604.1389053751323
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "ClosenessCentrality" : 0.42857142857142855,
        "Eccentricity" : 4,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Ni2+",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "Ni2+",
        "SelfLoops" : 0,
        "SUID" : 161,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.3333333333333335,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -139.88872497617626,
        "y" : -906.1216152012437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "ClosenessCentrality" : 0.5714285714285714,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.5,
        "Stress" : 222,
        "shared_name" : "Mn2+",
        "BetweennessCentrality" : 0.009801324503311257,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "Mn2+",
        "SelfLoops" : 0,
        "SUID" : 160,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.75,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.5
      },
      "position" : {
        "x" : -76.10072632275399,
        "y" : -911.1927612329584
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "ClosenessCentrality" : 0.6,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cGMP",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "cGMP",
        "SelfLoops" : 0,
        "SUID" : 159,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.6666666666666667,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -909.3135600223745,
        "y" : 586.3543460032934
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "ClosenessCentrality" : 0.6,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cAMP",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "cAMP",
        "SelfLoops" : 0,
        "SUID" : 158,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.6666666666666667,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -893.3142313470807,
        "y" : 614.0659961558956
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "ClosenessCentrality" : 0.5,
        "Eccentricity" : 3,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "K+",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "K+",
        "SelfLoops" : 0,
        "SUID" : 157,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -12.119521589349802,
        "y" : -912.2080125054053
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "ClosenessCentrality" : 0.5581395348837209,
        "Eccentricity" : 2,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "温度",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "温度",
        "SelfLoops" : 0,
        "SUID" : 156,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.7916666666666667,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.6
      },
      "position" : {
        "x" : -698.6764617518273,
        "y" : 144.0300034563188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik33-Rre31",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik33-Rre31",
        "SelfLoops" : 0,
        "SUID" : 155,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1036.0168801546056,
        "y" : 128.06540615641438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik46-Rre16",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik46-Rre16",
        "SelfLoops" : 0,
        "SUID" : 154,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -203.2266657926159,
        "y" : 1089.1565472280236
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik41-Rre17",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik41-Rre17",
        "SelfLoops" : 0,
        "SUID" : 153,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 975.720729990281,
        "y" : 191.9258342856083
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik36-Rre19",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik36-Rre19",
        "SelfLoops" : 0,
        "SUID" : 152,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -417.7114846875927,
        "y" : 1026.1781220673709
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik34-Rre1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik34-Rre1",
        "SelfLoops" : 0,
        "SUID" : 151,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 979.7791796253185,
        "y" : 64.0761469461072
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik33-Rre26",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik33-Rre26",
        "SelfLoops" : 0,
        "SUID" : 150,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : -1034.4943227340768,
        "y" : 160.0278198816245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik32-Rre38",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "Hik32-Rre38",
        "SelfLoops" : 0,
        "SUID" : 149,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 114.78251889373757,
        "y" : 752.9777687970341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 407,
        "shared_name" : "Hik31-Rre34",
        "BetweennessCentrality" : 0.017969094922737308,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "Hik31-Rre34",
        "SelfLoops" : 0,
        "SUID" : 148,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 972.1740564102928,
        "y" : -31.585777669215986
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "ClosenessCentrality" : 0.6666666666666666,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 256,
        "shared_name" : "Hik30-Rre33",
        "BetweennessCentrality" : 0.01130242825607064,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "Hik30-Rre33",
        "SelfLoops" : 0,
        "SUID" : 147,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.5
      },
      "position" : {
        "x" : -108.03496002362942,
        "y" : -909.1632809600369
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik29-Rre14",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik29-Rre14",
        "SelfLoops" : 0,
        "SUID" : 146,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 701.698693106859,
        "y" : -599.8088454860731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik29-Rre38",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik29-Rre38",
        "SelfLoops" : 0,
        "SUID" : 145,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 679.2524385351024,
        "y" : -622.6141020717862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "ClosenessCentrality" : 0.4444444444444444,
        "Eccentricity" : 3,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.5,
        "Stress" : 34,
        "shared_name" : "Hik27-Rre16",
        "BetweennessCentrality" : 0.001501103752759382,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "Hik27-Rre16",
        "SelfLoops" : 0,
        "SUID" : 144,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.25,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.5
      },
      "position" : {
        "x" : -44.11817893993725,
        "y" : -912.2080125054053
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik21-Rre20",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik21-Rre20",
        "SelfLoops" : 0,
        "SUID" : 143,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 19.86302579346716,
        "y" : 1103.3343143354807
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 114,
        "shared_name" : "Hik20-Rre19",
        "BetweennessCentrality" : 0.005033112582781457,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "Hik20-Rre19",
        "SelfLoops" : 0,
        "SUID" : 142,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 19.86302579346693,
        "y" : -911.1927612329584
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hik19-Rre41",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hik19-Rre41",
        "SelfLoops" : 0,
        "SUID" : 141,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 503.53832670307463,
        "y" : 952.9387600576788
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "ClosenessCentrality" : 0.5434782608695652,
        "Eccentricity" : 2,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "�?",
        "SelfLoops" : 0,
        "SUID" : 140,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.84,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.75
      },
      "position" : {
        "x" : -698.6764617518271,
        "y" : 48.11154964620141
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre17",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre17",
        "SelfLoops" : 0,
        "SUID" : 139,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 947.9661563385242,
        "y" : 349.3298432480565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre8",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre8",
        "SelfLoops" : 0,
        "SUID" : 138,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -924.4256003206194,
        "y" : 558.1490218558108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre19",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre19",
        "SelfLoops" : 0,
        "SUID" : 137,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 723.4100832764246,
        "y" : -576.3028971081578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre3",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre3",
        "SelfLoops" : 0,
        "SUID" : 136,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 419.68046169503566,
        "y" : -807.4544700180174
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre9",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "Rre9",
        "SelfLoops" : 0,
        "SUID" : 135,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.5
      },
      "position" : {
        "x" : 206.81560136451048,
        "y" : -533.8128644543112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre12",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre12",
        "SelfLoops" : 0,
        "SUID" : 134,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 764.5415862498309,
        "y" : -527.2842806708015
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre29",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre29",
        "SelfLoops" : 0,
        "SUID" : 133,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 853.0758594930879,
        "y" : -394.2127929007709
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre5",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre5",
        "SelfLoops" : 0,
        "SUID" : 132,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 837.0765308177942,
        "y" : -421.9244430533733
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "ClosenessCentrality" : 0.5555555555555556,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "磷酸�?",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "磷酸�?",
        "SelfLoops" : 0,
        "SUID" : 131,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 820.2060237332224,
        "y" : -449.1145159284086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre42",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre42",
        "SelfLoops" : 0,
        "SUID" : 130,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 868.1878997913326,
        "y" : -366.0074687532888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "129",
        "ClosenessCentrality" : 0.5531914893617021,
        "Eccentricity" : 2,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 3206,
        "shared_name" : "氧化",
        "BetweennessCentrality" : 0.11801324503311258,
        "EdgeCount" : 6,
        "Indegree" : 1,
        "name" : "氧化",
        "SelfLoops" : 0,
        "SUID" : 129,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8076923076923077,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.833333333333334
      },
      "position" : {
        "x" : -693.546585736262,
        "y" : 0.3967119682124576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "128",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre33",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre33",
        "SelfLoops" : 0,
        "SUID" : 128,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 503.53832670307463,
        "y" : -760.7972069551565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "127",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre1",
        "SelfLoops" : 0,
        "SUID" : 127,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 476.08400945048095,
        "y" : -777.2341937968577
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "ClosenessCentrality" : 0.5714285714285714,
        "Eccentricity" : 2,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "高渗",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "高渗",
        "SelfLoops" : 0,
        "SUID" : 126,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.75,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.5
      },
      "position" : {
        "x" : 335.3380113884699,
        "y" : -469.47913944731596
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "125",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rre10",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rre10",
        "SelfLoops" : 0,
        "SUID" : 125,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -203.2266657926159,
        "y" : -897.0149941255013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "124",
        "ClosenessCentrality" : 0.5849056603773585,
        "Eccentricity" : 3,
        "Outdegree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "光照",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 10,
        "Indegree" : 0,
        "name" : "光照",
        "SelfLoops" : 0,
        "SUID" : 124,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.7096774193548387,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.5
      },
      "position" : {
        "x" : 537.4310657339364,
        "y" : 459.5276382043703
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "123",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Sll5060",
        "BetweennessCentrality" : 1.4517058256469928E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Sll5060",
        "SelfLoops" : 0,
        "SUID" : 123,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.333333333333336
      },
      "position" : {
        "x" : -76.07807716970137,
        "y" : 766.6283880384451
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "122",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Sll1334 ",
        "BetweennessCentrality" : 1.8130636411862347E-4,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Sll1334 ",
        "SelfLoops" : 0,
        "SUID" : 122,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.666666666666668
      },
      "position" : {
        "x" : 583.3998875301871,
        "y" : -183.20047348093453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "121",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 567,
        "shared_name" : "Hik47-Slr6041 ",
        "BetweennessCentrality" : 0.011004110718296831,
        "EdgeCount" : 6,
        "Indegree" : 3,
        "name" : "Hik47-Slr6041 ",
        "SelfLoops" : 0,
        "SUID" : 121,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.666666666666668
      },
      "position" : {
        "x" : 601.7647907409311,
        "y" : 331.0052281804094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 12,
        "shared_name" : "Hik46-Slr6001",
        "BetweennessCentrality" : 1.9111749975757368E-4,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "Hik46-Slr6001",
        "SelfLoops" : 0,
        "SUID" : 120,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.25
      },
      "position" : {
        "x" : -123.79291484769055,
        "y" : 761.49851202288
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "119",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 4,
        "shared_name" : "Hik45-Sll5059 ",
        "BetweennessCentrality" : 4.705922617519722E-6,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "Hik45-Sll5059 ",
        "SelfLoops" : 0,
        "SUID" : 119,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.0
      },
      "position" : {
        "x" : 601.764790740929,
        "y" : -138.8636750778926
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 116,
        "shared_name" : "Hik44-Slr1212",
        "BetweennessCentrality" : 0.001110806818370429,
        "EdgeCount" : 4,
        "Indegree" : 2,
        "name" : "Hik44-Slr1212",
        "SelfLoops" : 0,
        "SUID" : 118,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 27.0
      },
      "position" : {
        "x" : 561.9188250042806,
        "y" : 418.25572271102783
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "117",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 16,
        "shared_name" : "Hik43-Slr0322",
        "BetweennessCentrality" : 1.6168409284072303E-4,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "Hik43-Slr0322",
        "SelfLoops" : 0,
        "SUID" : 117,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.4
      },
      "position" : {
        "x" : -171.02021942302224,
        "y" : 752.9777687970345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik42-Sll1555",
        "BetweennessCentrality" : 1.4517058256469928E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik42-Sll1555",
        "SelfLoops" : 0,
        "SUID" : 116,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.333333333333336
      },
      "position" : {
        "x" : -391.5757119177574,
        "y" : 661.6206925498377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 853,
        "shared_name" : "Hik41-Sll1229",
        "BetweennessCentrality" : 0.028741522209102678,
        "EdgeCount" : 7,
        "Indegree" : 3,
        "name" : "Hik41-Sll1229",
        "SelfLoops" : 0,
        "SUID" : 115,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.857142857142858
      },
      "position" : {
        "x" : 642.4387612225408,
        "y" : 144.03000345631312
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik40-Slr2099",
        "BetweennessCentrality" : 1.4517058256469928E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik40-Slr2099",
        "SelfLoops" : 0,
        "SUID" : 114,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.333333333333336
      },
      "position" : {
        "x" : -430.9955345558815,
        "y" : 634.2510205432029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "113",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik39-Sll1296",
        "BetweennessCentrality" : 1.4517058256469928E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik39-Sll1296",
        "SelfLoops" : 0,
        "SUID" : 113,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.333333333333336
      },
      "position" : {
        "x" : -468.362389958455,
        "y" : 604.1389053751338
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "112",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik38-Slr1400",
        "BetweennessCentrality" : 1.4517058256469928E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik38-Slr1400",
        "SelfLoops" : 0,
        "SUID" : 112,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.333333333333336
      },
      "position" : {
        "x" : -503.4858651955963,
        "y" : 571.4377914822121
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik37-Sll0094",
        "BetweennessCentrality" : 1.101308124255914E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik37-Sll0094",
        "SelfLoops" : 0,
        "SUID" : 111,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.666666666666664
      },
      "position" : {
        "x" : 412.12468942916746,
        "y" : -411.9973522726123
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 16,
        "shared_name" : "Hik36-Slr0073",
        "BetweennessCentrality" : 3.2847339870287657E-4,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "Hik36-Slr0073",
        "SelfLoops" : 0,
        "SUID" : 110,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.0
      },
      "position" : {
        "x" : -263.05330189379725,
        "y" : 725.9544175568335
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "109",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 116,
        "shared_name" : "Hik35-Slr0473",
        "BetweennessCentrality" : 7.063773196531546E-4,
        "EdgeCount" : 4,
        "Indegree" : 2,
        "name" : "Hik35-Slr0473",
        "SelfLoops" : 0,
        "SUID" : 109,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 33.0
      },
      "position" : {
        "x" : 251.1523997675548,
        "y" : 707.5895143460907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 1849,
        "shared_name" : "Hik34-Slr1285",
        "BetweennessCentrality" : 0.06507355907094087,
        "EdgeCount" : 11,
        "Indegree" : 4,
        "name" : "Hik34-Slr1285",
        "SelfLoops" : 0,
        "SUID" : 108,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.1
      },
      "position" : {
        "x" : 644.1516293555227,
        "y" : 96.07077655126113
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 6790,
        "shared_name" : "Hik33-Sll0698",
        "BetweennessCentrality" : 0.2708974146182231,
        "EdgeCount" : 19,
        "Indegree" : 7,
        "name" : "Hik33-Sll0698",
        "SelfLoops" : 0,
        "SUID" : 107,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.315789473684211
      },
      "position" : {
        "x" : -700.3893298848093,
        "y" : 96.07077655126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 174,
        "shared_name" : "Hik32-Sll1475",
        "BetweennessCentrality" : 0.0019867305205361566,
        "EdgeCount" : 5,
        "Indegree" : 2,
        "name" : "Hik32-Sll1475",
        "SelfLoops" : 0,
        "SUID" : 106,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.8
      },
      "position" : {
        "x" : 206.81560136451253,
        "y" : 725.9544175568326
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 174,
        "shared_name" : "Hik32-Sll1473",
        "BetweennessCentrality" : 0.0019867305205361566,
        "EdgeCount" : 5,
        "Indegree" : 2,
        "name" : "Hik32-Sll1473",
        "SelfLoops" : 0,
        "SUID" : 105,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.8
      },
      "position" : {
        "x" : 161.28163084776236,
        "y" : 741.109578115258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "ClosenessCentrality" : 0.875,
        "Eccentricity" : 2,
        "Outdegree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 2611,
        "shared_name" : "Hik31-Sll0790",
        "BetweennessCentrality" : 0.09757143963661909,
        "EdgeCount" : 11,
        "Indegree" : 5,
        "name" : "Hik31-Sll0790",
        "SelfLoops" : 0,
        "SUID" : 104,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.1428571428571428,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.090909090909092
      },
      "position" : {
        "x" : 637.3088852069753,
        "y" : 0.39671196821336707
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "ClosenessCentrality" : 0.625,
        "Eccentricity" : 3,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 475,
        "shared_name" : "Hik30-Sll0798",
        "BetweennessCentrality" : 0.02063619313183621,
        "EdgeCount" : 5,
        "Indegree" : 2,
        "name" : "Hik30-Sll0798",
        "SelfLoops" : 0,
        "SUID" : 103,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.6,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.2
      },
      "position" : {
        "x" : -123.79291484769067,
        "y" : -569.3569589203578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 16,
        "shared_name" : "Hik29-Slr0311",
        "BetweennessCentrality" : 3.6421396424476666E-4,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "Hik29-Slr0311",
        "SelfLoops" : 0,
        "SUID" : 102,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.8
      },
      "position" : {
        "x" : 447.24816466630875,
        "y" : -379.2962383796909
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 180,
        "shared_name" : "Hik28-Sll0474",
        "BetweennessCentrality" : 0.0028657737057876474,
        "EdgeCount" : 4,
        "Indegree" : 2,
        "name" : "Hik28-Sll0474",
        "SelfLoops" : 0,
        "SUID" : 101,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 25.75
      },
      "position" : {
        "x" : -685.025842510417,
        "y" : 238.9721457096391
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "ClosenessCentrality" : 0.8,
        "Eccentricity" : 2,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.05,
        "Stress" : 434,
        "shared_name" : "Hik27-Slr0640",
        "BetweennessCentrality" : 0.018826038606449897,
        "EdgeCount" : 5,
        "Indegree" : 2,
        "name" : "Hik27-Slr0640",
        "SelfLoops" : 0,
        "SUID" : 100,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.25,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.4
      },
      "position" : {
        "x" : -76.07807716970183,
        "y" : -574.4868349359228
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 180,
        "shared_name" : "Hik26-Slr0484",
        "BetweennessCentrality" : 0.002225876951735571,
        "EdgeCount" : 4,
        "Indegree" : 2,
        "name" : "Hik26-Slr0484",
        "SelfLoops" : 0,
        "SUID" : 99,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.75
      },
      "position" : {
        "x" : -693.5465857362623,
        "y" : 191.74484113430776
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik25-Slr0222",
        "BetweennessCentrality" : 1.4517058256469928E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik25-Slr0222",
        "SelfLoops" : 0,
        "SUID" : 98,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.333333333333336
      },
      "position" : {
        "x" : -536.1869790885177,
        "y" : 536.3143162450708
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 116,
        "shared_name" : "Hik24-Slr1969",
        "BetweennessCentrality" : 0.0027959740118988522,
        "EdgeCount" : 4,
        "Indegree" : 2,
        "name" : "Hik24-Slr1969",
        "SelfLoops" : 0,
        "SUID" : 97,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 30.5
      },
      "position" : {
        "x" : 67.555214318406,
        "y" : 761.4985120228798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik23-Slr1324",
        "BetweennessCentrality" : 1.4517058256469928E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik23-Slr1324",
        "SelfLoops" : 0,
        "SUID" : 96,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.333333333333336
      },
      "position" : {
        "x" : -566.2990942565867,
        "y" : 498.9474608424971
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 362,
        "shared_name" : "Hik22-Slr2104",
        "BetweennessCentrality" : 0.01564365613110415,
        "EdgeCount" : 5,
        "Indegree" : 3,
        "name" : "Hik22-Slr2104",
        "SelfLoops" : 0,
        "SUID" : 95,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.8
      },
      "position" : {
        "x" : -593.6687662632212,
        "y" : 459.52763820437326
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 12,
        "shared_name" : "Hik21-Slr2098",
        "BetweennessCentrality" : 1.9819600509736446E-4,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "Hik21-Slr2098",
        "SelfLoops" : 0,
        "SUID" : 94,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.25
      },
      "position" : {
        "x" : 19.84037664041682,
        "y" : 766.6283880384449
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "ClosenessCentrality" : 0.8,
        "Eccentricity" : 2,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 364,
        "shared_name" : "Hik20-Sll1590",
        "BetweennessCentrality" : 0.015735530880180582,
        "EdgeCount" : 5,
        "Indegree" : 2,
        "name" : "Hik20-Sll1590",
        "SelfLoops" : 0,
        "SUID" : 93,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.25,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.2
      },
      "position" : {
        "x" : -28.118850264643015,
        "y" : -576.1997030689049
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 360,
        "shared_name" : "Hik19-Sll1905",
        "BetweennessCentrality" : 0.01103732794861704,
        "EdgeCount" : 6,
        "Indegree" : 2,
        "name" : "Hik19-Sll1905",
        "SelfLoops" : 0,
        "SUID" : 92,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.0
      },
      "position" : {
        "x" : 335.33801138847264,
        "y" : 661.6206925498366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 16,
        "shared_name" : "Hik18-Sll0043",
        "BetweennessCentrality" : 2.4998431359127493E-4,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "Hik18-Sll0043",
        "SelfLoops" : 0,
        "SUID" : 91,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.2
      },
      "position" : {
        "x" : -307.3901002968395,
        "y" : 707.5895143460916
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 4,
        "shared_name" : "Hik17-Sll1687",
        "BetweennessCentrality" : 4.705922617519722E-6,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "Hik17-Sll1687",
        "SelfLoops" : 0,
        "SUID" : 90,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.0
      },
      "position" : {
        "x" : 616.919951299354,
        "y" : -93.32970456114253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 958,
        "shared_name" : "Hik16-Slr1805",
        "BetweennessCentrality" : 0.02394009305825267,
        "EdgeCount" : 7,
        "Indegree" : 3,
        "name" : "Hik16-Slr1805",
        "SelfLoops" : 0,
        "SUID" : 89,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.857142857142858
      },
      "position" : {
        "x" : 628.7881419811314,
        "y" : 238.9721457096341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 12,
        "shared_name" : "Hik15-Sll1353",
        "BetweennessCentrality" : 1.063918073329018E-4,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "Hik15-Sll1353",
        "SelfLoops" : 0,
        "SUID" : 88,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 25.0
      },
      "position" : {
        "x" : 19.840376640415798,
        "y" : -574.4868349359228
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 16,
        "shared_name" : "Hik14-Slr1759",
        "BetweennessCentrality" : 3.6771794125867744E-4,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "Hik14-Slr1759",
        "SelfLoops" : 0,
        "SUID" : 87,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.8
      },
      "position" : {
        "x" : -618.1565255335654,
        "y" : 418.25572271103124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 16,
        "shared_name" : "Hik13-Sll1003",
        "BetweennessCentrality" : 1.876135227436629E-4,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "Hik13-Sll1003",
        "SelfLoops" : 0,
        "SUID" : 86,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 25.2
      },
      "position" : {
        "x" : 114.78251889373598,
        "y" : -560.8362156945122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik12-Sll1672",
        "BetweennessCentrality" : 2.15955635962607E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik12-Sll1672",
        "SelfLoops" : 0,
        "SUID" : 85,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 29.333333333333332
      },
      "position" : {
        "x" : -28.118850264642333,
        "y" : 768.3412561714272
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 12,
        "shared_name" : "Hik11-Slr1414",
        "BetweennessCentrality" : 1.876135227436629E-4,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "Hik11-Slr1414",
        "SelfLoops" : 0,
        "SUID" : 84,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 30.75
      },
      "position" : {
        "x" : 479.94927855923004,
        "y" : -344.17276314254946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 180,
        "shared_name" : "Hik10-Slr0533",
        "BetweennessCentrality" : 0.006375707480622085,
        "EdgeCount" : 5,
        "Indegree" : 2,
        "name" : "Hik10-Slr0533",
        "SelfLoops" : 0,
        "SUID" : 83,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.2
      },
      "position" : {
        "x" : 251.15239976755242,
        "y" : -515.4479612435694
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 12,
        "shared_name" : "Hik9-Slr0210",
        "BetweennessCentrality" : 9.931330199311102E-5,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "Hik9-Slr0210",
        "SelfLoops" : 0,
        "SUID" : 82,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : 161.28163084776043,
        "y" : -548.9680250127362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 655,
        "shared_name" : "Hik8-Sll0750",
        "BetweennessCentrality" : 0.028576134494046092,
        "EdgeCount" : 7,
        "Indegree" : 2,
        "name" : "Hik8-Sll0750",
        "SelfLoops" : 0,
        "SUID" : 81,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 18.0
      },
      "position" : {
        "x" : 510.0613937272991,
        "y" : -306.80590773997596
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 260,
        "shared_name" : "Hik7-Sll0337",
        "BetweennessCentrality" : 0.011136840895812095,
        "EdgeCount" : 6,
        "Indegree" : 2,
        "name" : "Hik7-Sll0337",
        "SelfLoops" : 0,
        "SUID" : 80,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.833333333333332
      },
      "position" : {
        "x" : 537.4310657339337,
        "y" : -267.38608510185213
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik6-Sll1871",
        "BetweennessCentrality" : 1.8091586582349913E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik6-Sll1871",
        "SelfLoops" : 0,
        "SUID" : 79,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.666666666666664
      },
      "position" : {
        "x" : 374.75783402659374,
        "y" : -442.1094674406814
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 12,
        "shared_name" : "Hik5-Sll1888",
        "BetweennessCentrality" : 1.876135227436629E-4,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "Hik5-Sll1888",
        "SelfLoops" : 0,
        "SUID" : 78,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 30.75
      },
      "position" : {
        "x" : 561.9188250042783,
        "y" : -226.1141696085101
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 8,
        "shared_name" : "Hik4-Sll1228",
        "BetweennessCentrality" : 1.4517058256469928E-5,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Hik4-Sll1228",
        "SelfLoops" : 0,
        "SUID" : 77,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.333333333333336
      },
      "position" : {
        "x" : -639.6375880594744,
        "y" : 375.34202658345566
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 341,
        "shared_name" : "Hik3-Sll1124",
        "BetweennessCentrality" : 0.0034068924042742004,
        "EdgeCount" : 5,
        "Indegree" : 3,
        "name" : "Hik3-Sll1124",
        "SelfLoops" : 0,
        "SUID" : 76,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 27.6
      },
      "position" : {
        "x" : -673.1576518286411,
        "y" : 285.47125766366366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 240,
        "shared_name" : "Hik2-Slr1147",
        "BetweennessCentrality" : 0.00901763559779885,
        "EdgeCount" : 6,
        "Indegree" : 2,
        "name" : "Hik2-Slr1147",
        "SelfLoops" : 0,
        "SUID" : 75,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : 294.0660958951279,
        "y" : -493.9668987176604
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 174,
        "shared_name" : "Hik1-Slr1393",
        "BetweennessCentrality" : 0.0032670837214191584,
        "EdgeCount" : 5,
        "Indegree" : 2,
        "name" : "Hik1-Slr1393",
        "SelfLoops" : 0,
        "SUID" : 74,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.6
      },
      "position" : {
        "x" : -171.020219423022,
        "y" : -560.8362156945125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "ClosenessCentrality" : 0.6264367816091954,
        "Eccentricity" : 4,
        "Outdegree" : 50,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 210,
        "shared_name" : "Histidine kinase",
        "BetweennessCentrality" : 0.004793556353535926,
        "EdgeCount" : 51,
        "Indegree" : 1,
        "name" : "Histidine kinase",
        "SelfLoops" : 0,
        "SUID" : 73,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.5963302752293578,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.823529411764706
      },
      "position" : {
        "x" : 628.78814198113,
        "y" : -46.83059260711798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "ClosenessCentrality" : 0.376,
        "Eccentricity" : 4,
        "Outdegree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 36,
        "shared_name" : "spK",
        "BetweennessCentrality" : 9.459579952499453E-4,
        "EdgeCount" : 13,
        "Indegree" : 1,
        "name" : "spK",
        "SelfLoops" : 0,
        "SUID" : 72,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.6595744680851063,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.923076923076923
      },
      "position" : {
        "x" : -217.51933137704657,
        "y" : -548.9680250127365
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "ClosenessCentrality" : 0.39285714285714285,
        "Eccentricity" : 5,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Synechocystis",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "Synechocystis",
        "SelfLoops" : 0,
        "SUID" : 71,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.5454545454545454,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : -263.0533018937965,
        "y" : -533.8128644543115
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "528",
        "source" : "230",
        "target" : "184",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "SpkB (interacts with) GlyS",
        "shared_interaction" : "interacts with",
        "name" : "SpkB (interacts with) GlyS",
        "interaction" : "interacts with",
        "SUID" : 528,
        "BEND_MAP_ID" : 516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "source" : "228",
        "target" : "229",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "SpkA  (interacts with) pliA",
        "shared_interaction" : "interacts with",
        "name" : "SpkA  (interacts with) pliA",
        "interaction" : "interacts with",
        "SUID" : 527,
        "BEND_MAP_ID" : 514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "526",
        "source" : "220",
        "target" : "221",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "Hik14-Rre8 (interacts with) pH",
        "shared_interaction" : "interacts with",
        "name" : "Hik14-Rre8 (interacts with) pH",
        "interaction" : "interacts with",
        "SUID" : 526,
        "BEND_MAP_ID" : 497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "source" : "218",
        "target" : "219",
        "EdgeBetweenness" : 349.0,
        "shared_name" : "nrsBACD (interacts with) Ni2+转运",
        "shared_interaction" : "interacts with",
        "name" : "nrsBACD (interacts with) Ni2+转运",
        "interaction" : "interacts with",
        "SUID" : 525,
        "BEND_MAP_ID" : 494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "source" : "215",
        "target" : "216",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "Hik7-Rre29 (interacts with) 碱�?�磷酸酶",
        "shared_interaction" : "interacts with",
        "name" : "Hik7-Rre29 (interacts with) 碱�?�磷酸酶",
        "interaction" : "interacts with",
        "SUID" : 524,
        "BEND_MAP_ID" : 487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "source" : "209",
        "target" : "210",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "Rre26 (interacts with) hliB",
        "shared_interaction" : "interacts with",
        "name" : "Rre26 (interacts with) hliB",
        "interaction" : "interacts with",
        "SUID" : 523,
        "BEND_MAP_ID" : 476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "522",
        "source" : "203",
        "target" : "204",
        "EdgeBetweenness" : 225.0,
        "shared_name" : "Sll1334 (interacts with) 异养生长",
        "shared_interaction" : "interacts with",
        "name" : "Sll1334 (interacts with) 异养生长",
        "interaction" : "interacts with",
        "SUID" : 522,
        "BEND_MAP_ID" : 462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "source" : "201",
        "target" : "199",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "黑暗 (interacts with) Hik47-Slr6041",
        "shared_interaction" : "interacts with",
        "name" : "黑暗 (interacts with) Hik47-Slr6041",
        "interaction" : "interacts with",
        "SUID" : 521,
        "BEND_MAP_ID" : 455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "520",
        "source" : "200",
        "target" : "199",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "细胞生长 (interacts with) Hik47-Slr6041",
        "shared_interaction" : "interacts with",
        "name" : "细胞生长 (interacts with) Hik47-Slr6041",
        "interaction" : "interacts with",
        "SUID" : 520,
        "BEND_MAP_ID" : 453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "source" : "200",
        "target" : "104",
        "EdgeBetweenness" : 1040.0,
        "shared_name" : "细胞生长 (interacts with) Hik31-Sll0790",
        "shared_interaction" : "interacts with",
        "name" : "细胞生长 (interacts with) Hik31-Sll0790",
        "interaction" : "interacts with",
        "SUID" : 519,
        "BEND_MAP_ID" : 452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "source" : "197",
        "target" : "81",
        "EdgeBetweenness" : 762.0,
        "shared_name" : "光激活异养生�? (interacts with) Hik8-Sll0750",
        "shared_interaction" : "interacts with",
        "name" : "光激活异养生�? (interacts with) Hik8-Sll0750",
        "interaction" : "interacts with",
        "SUID" : 518,
        "BEND_MAP_ID" : 445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "source" : "194",
        "target" : "189",
        "EdgeBetweenness" : 124.30897009966777,
        "shared_name" : "spkL-Sll0095 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "spkL-Sll0095 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 517,
        "BEND_MAP_ID" : 345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "516",
        "source" : "193",
        "target" : "189",
        "EdgeBetweenness" : 123.30897009966777,
        "shared_name" : "SpkJ-Slr0889 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "SpkJ-Slr0889 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 516,
        "BEND_MAP_ID" : 342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "source" : "192",
        "target" : "190",
        "EdgeBetweenness" : 122.45263157894738,
        "shared_name" : "SpkI-Sll1770 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "SpkI-Sll1770 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 515,
        "BEND_MAP_ID" : 340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "514",
        "source" : "191",
        "target" : "189",
        "EdgeBetweenness" : 121.30897009966777,
        "shared_name" : "SpkH-Sll0005 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "SpkH-Sll0005 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 514,
        "BEND_MAP_ID" : 338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "source" : "188",
        "target" : "190",
        "EdgeBetweenness" : 118.45263157894738,
        "shared_name" : "SpkK-Slr1919  (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "SpkK-Slr1919  (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 513,
        "BEND_MAP_ID" : 343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "source" : "188",
        "target" : "186",
        "EdgeBetweenness" : 119.0,
        "shared_name" : "SpkK-Slr1919  (interacts with) GroES (in vitro assay)",
        "shared_interaction" : "interacts with",
        "name" : "SpkK-Slr1919  (interacts with) GroES (in vitro assay)",
        "interaction" : "interacts with",
        "SUID" : 512,
        "BEND_MAP_ID" : 327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "source" : "187",
        "target" : "190",
        "EdgeBetweenness" : 117.45263157894738,
        "shared_name" : "spkF-Slr1225 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "spkF-Slr1225 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 511,
        "BEND_MAP_ID" : 335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "510",
        "source" : "187",
        "target" : "186",
        "EdgeBetweenness" : 118.0,
        "shared_name" : "spkF-Slr1225 (interacts with) GroES (in vitro assay)",
        "shared_interaction" : "interacts with",
        "name" : "spkF-Slr1225 (interacts with) GroES (in vitro assay)",
        "interaction" : "interacts with",
        "SUID" : 510,
        "BEND_MAP_ID" : 325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "source" : "185",
        "target" : "190",
        "EdgeBetweenness" : 115.45263157894738,
        "shared_name" : "spkC-Slr0599 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "spkC-Slr0599 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 509,
        "BEND_MAP_ID" : 332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "508",
        "source" : "185",
        "target" : "186",
        "EdgeBetweenness" : 116.0,
        "shared_name" : "spkC-Slr0599 (interacts with) GroES (in vitro assay)",
        "shared_interaction" : "interacts with",
        "name" : "spkC-Slr0599 (interacts with) GroES (in vitro assay)",
        "interaction" : "interacts with",
        "SUID" : 508,
        "BEND_MAP_ID" : 323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "source" : "181",
        "target" : "189",
        "EdgeBetweenness" : 111.30897009966777,
        "shared_name" : "spkE-Slr1443 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "spkE-Slr1443 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 507,
        "BEND_MAP_ID" : 334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "source" : "181",
        "target" : "182",
        "EdgeBetweenness" : 114.0,
        "shared_name" : "spkE-Slr1443 (interacts with) 低温",
        "shared_interaction" : "interacts with",
        "name" : "spkE-Slr1443 (interacts with) 低温",
        "interaction" : "interacts with",
        "SUID" : 506,
        "BEND_MAP_ID" : 316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "source" : "178",
        "target" : "189",
        "EdgeBetweenness" : 108.30897009966777,
        "shared_name" : "spkG-Slr0152 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "spkG-Slr0152 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 505,
        "BEND_MAP_ID" : 336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "504",
        "source" : "178",
        "target" : "183",
        "EdgeBetweenness" : 111.0,
        "shared_name" : "spkG-Slr0152 (interacts with) 高盐",
        "shared_interaction" : "interacts with",
        "name" : "spkG-Slr0152 (interacts with) 高盐",
        "interaction" : "interacts with",
        "SUID" : 504,
        "BEND_MAP_ID" : 318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "source" : "178",
        "target" : "179",
        "EdgeBetweenness" : 111.0,
        "shared_name" : "spkG-Slr0152 (interacts with) 高盐条件下的生长缺陷",
        "shared_interaction" : "interacts with",
        "name" : "spkG-Slr0152 (interacts with) 高盐条件下的生长缺陷",
        "interaction" : "interacts with",
        "SUID" : 503,
        "BEND_MAP_ID" : 310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "502",
        "source" : "176",
        "target" : "190",
        "EdgeBetweenness" : 106.45263157894738,
        "shared_name" : "spkD-Sll0776 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "spkD-Sll0776 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 502,
        "BEND_MAP_ID" : 333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "source" : "176",
        "target" : "180",
        "EdgeBetweenness" : 109.0,
        "shared_name" : "spkD-Sll0776 (interacts with) TCA循环代谢�?",
        "shared_interaction" : "interacts with",
        "name" : "spkD-Sll0776 (interacts with) TCA循环代谢�?",
        "interaction" : "interacts with",
        "SUID" : 501,
        "BEND_MAP_ID" : 313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "source" : "176",
        "target" : "177",
        "EdgeBetweenness" : 109.0,
        "shared_name" : "spkD-Sll0776 (interacts with) 低无机碳条件下的生长缺陷",
        "shared_interaction" : "interacts with",
        "name" : "spkD-Sll0776 (interacts with) 低无机碳条件下的生长缺陷",
        "interaction" : "interacts with",
        "SUID" : 500,
        "BEND_MAP_ID" : 307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "source" : "175",
        "target" : "189",
        "EdgeBetweenness" : 105.30897009966777,
        "shared_name" : "SpkB-Slr1697 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "SpkB-Slr1697 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 499,
        "BEND_MAP_ID" : 330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "498",
        "source" : "175",
        "target" : "184",
        "EdgeBetweenness" : 108.0,
        "shared_name" : "SpkB-Slr1697 (interacts with) GlyS",
        "shared_interaction" : "interacts with",
        "name" : "SpkB-Slr1697 (interacts with) GlyS",
        "interaction" : "interacts with",
        "SUID" : 498,
        "BEND_MAP_ID" : 320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "source" : "175",
        "target" : "129",
        "EdgeBetweenness" : 2781.0,
        "shared_name" : "SpkB-Slr1697 (interacts with) 氧化",
        "shared_interaction" : "interacts with",
        "name" : "SpkB-Slr1697 (interacts with) 氧化",
        "interaction" : "interacts with",
        "SUID" : 497,
        "BEND_MAP_ID" : 311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "496",
        "source" : "175",
        "target" : "174",
        "EdgeBetweenness" : 106.5,
        "shared_name" : "SpkB-Slr1697 (interacts with) 运动性缺�?",
        "shared_interaction" : "interacts with",
        "name" : "SpkB-Slr1697 (interacts with) 运动性缺�?",
        "interaction" : "interacts with",
        "SUID" : 496,
        "BEND_MAP_ID" : 304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "source" : "173",
        "target" : "189",
        "EdgeBetweenness" : 103.30897009966777,
        "shared_name" : "SpkA-Sll1574&1575 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "SpkA-Sll1574&1575 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 495,
        "BEND_MAP_ID" : 329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "source" : "173",
        "target" : "174",
        "EdgeBetweenness" : 104.5,
        "shared_name" : "SpkA-Sll1574&1575 (interacts with) 运动性缺�?",
        "shared_interaction" : "interacts with",
        "name" : "SpkA-Sll1574&1575 (interacts with) 运动性缺�?",
        "interaction" : "interacts with",
        "SUID" : 494,
        "BEND_MAP_ID" : 302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "source" : "164",
        "target" : "107",
        "EdgeBetweenness" : 1222.0,
        "shared_name" : "渗�?�压 (interacts with) Hik33-Sll0698",
        "shared_interaction" : "interacts with",
        "name" : "渗�?�压 (interacts with) Hik33-Sll0698",
        "interaction" : "interacts with",
        "SUID" : 493,
        "BEND_MAP_ID" : 272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "source" : "163",
        "target" : "121",
        "EdgeBetweenness" : 232.5,
        "shared_name" : "暗循�? (interacts with) Hik47-Slr6041 ",
        "shared_interaction" : "interacts with",
        "name" : "暗循�? (interacts with) Hik47-Slr6041 ",
        "interaction" : "interacts with",
        "SUID" : 492,
        "BEND_MAP_ID" : 279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "source" : "163",
        "target" : "104",
        "EdgeBetweenness" : 604.5,
        "shared_name" : "暗循�? (interacts with) Hik31-Sll0790",
        "shared_interaction" : "interacts with",
        "name" : "暗循�? (interacts with) Hik31-Sll0790",
        "interaction" : "interacts with",
        "SUID" : 491,
        "BEND_MAP_ID" : 263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "source" : "162",
        "target" : "203",
        "EdgeBetweenness" : 184.0,
        "shared_name" : "碳源 (interacts with) Sll1334",
        "shared_interaction" : "interacts with",
        "name" : "碳源 (interacts with) Sll1334",
        "interaction" : "interacts with",
        "SUID" : 490,
        "BEND_MAP_ID" : 468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "source" : "162",
        "target" : "107",
        "EdgeBetweenness" : 1073.3333333333323,
        "shared_name" : "碳源 (interacts with) Hik33-Sll0698",
        "shared_interaction" : "interacts with",
        "name" : "碳源 (interacts with) Hik33-Sll0698",
        "interaction" : "interacts with",
        "SUID" : 489,
        "BEND_MAP_ID" : 467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "source" : "162",
        "target" : "121",
        "EdgeBetweenness" : 199.33333333333314,
        "shared_name" : "碳源 (interacts with) Hik47-Slr6041 ",
        "shared_interaction" : "interacts with",
        "name" : "碳源 (interacts with) Hik47-Slr6041 ",
        "interaction" : "interacts with",
        "SUID" : 488,
        "BEND_MAP_ID" : 280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "source" : "162",
        "target" : "104",
        "EdgeBetweenness" : 567.3333333333336,
        "shared_name" : "碳源 (interacts with) Hik31-Sll0790",
        "shared_interaction" : "interacts with",
        "name" : "碳源 (interacts with) Hik31-Sll0790",
        "interaction" : "interacts with",
        "SUID" : 487,
        "BEND_MAP_ID" : 261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "486",
        "source" : "161",
        "target" : "103",
        "EdgeBetweenness" : 546.0,
        "shared_name" : "Ni2+ (interacts with) Hik30-Sll0798",
        "shared_interaction" : "interacts with",
        "name" : "Ni2+ (interacts with) Hik30-Sll0798",
        "interaction" : "interacts with",
        "SUID" : 486,
        "BEND_MAP_ID" : 259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "source" : "160",
        "target" : "100",
        "EdgeBetweenness" : 582.0,
        "shared_name" : "Mn2+ (interacts with) Hik27-Slr0640",
        "shared_interaction" : "interacts with",
        "name" : "Mn2+ (interacts with) Hik27-Slr0640",
        "interaction" : "interacts with",
        "SUID" : 485,
        "BEND_MAP_ID" : 256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "484",
        "source" : "159",
        "target" : "95",
        "EdgeBetweenness" : 267.0,
        "shared_name" : "cGMP (interacts with) Hik22-Slr2104",
        "shared_interaction" : "interacts with",
        "name" : "cGMP (interacts with) Hik22-Slr2104",
        "interaction" : "interacts with",
        "SUID" : 484,
        "BEND_MAP_ID" : 252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "source" : "158",
        "target" : "95",
        "EdgeBetweenness" : 264.0,
        "shared_name" : "cAMP (interacts with) Hik22-Slr2104",
        "shared_interaction" : "interacts with",
        "name" : "cAMP (interacts with) Hik22-Slr2104",
        "interaction" : "interacts with",
        "SUID" : 483,
        "BEND_MAP_ID" : 250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "source" : "157",
        "target" : "93",
        "EdgeBetweenness" : 435.0,
        "shared_name" : "K+ (interacts with) Hik20-Sll1590",
        "shared_interaction" : "interacts with",
        "name" : "K+ (interacts with) Hik20-Sll1590",
        "interaction" : "interacts with",
        "SUID" : 482,
        "BEND_MAP_ID" : 248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "source" : "156",
        "target" : "108",
        "EdgeBetweenness" : 480.16666666666606,
        "shared_name" : "温度 (interacts with) Hik34-Slr1285",
        "shared_interaction" : "interacts with",
        "name" : "温度 (interacts with) Hik34-Slr1285",
        "interaction" : "interacts with",
        "SUID" : 481,
        "BEND_MAP_ID" : 274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "480",
        "source" : "156",
        "target" : "107",
        "EdgeBetweenness" : 967.5,
        "shared_name" : "温度 (interacts with) Hik33-Sll0698",
        "shared_interaction" : "interacts with",
        "name" : "温度 (interacts with) Hik33-Sll0698",
        "interaction" : "interacts with",
        "SUID" : 480,
        "BEND_MAP_ID" : 266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "source" : "156",
        "target" : "101",
        "EdgeBetweenness" : 150.5,
        "shared_name" : "温度 (interacts with) Hik28-Sll0474",
        "shared_interaction" : "interacts with",
        "name" : "温度 (interacts with) Hik28-Sll0474",
        "interaction" : "interacts with",
        "SUID" : 479,
        "BEND_MAP_ID" : 257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "source" : "156",
        "target" : "99",
        "EdgeBetweenness" : 136.16666666666657,
        "shared_name" : "温度 (interacts with) Hik26-Slr0484",
        "shared_interaction" : "interacts with",
        "name" : "温度 (interacts with) Hik26-Slr0484",
        "interaction" : "interacts with",
        "SUID" : 478,
        "BEND_MAP_ID" : 254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "source" : "156",
        "target" : "92",
        "EdgeBetweenness" : 329.6666666666665,
        "shared_name" : "温度 (interacts with) Hik19-Sll1905",
        "shared_interaction" : "interacts with",
        "name" : "温度 (interacts with) Hik19-Sll1905",
        "interaction" : "interacts with",
        "SUID" : 477,
        "BEND_MAP_ID" : 246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "source" : "148",
        "target" : "217",
        "EdgeBetweenness" : 485.0,
        "shared_name" : "Hik31-Rre34 (interacts with) Cu2+",
        "shared_interaction" : "interacts with",
        "name" : "Hik31-Rre34 (interacts with) Cu2+",
        "interaction" : "interacts with",
        "SUID" : 476,
        "BEND_MAP_ID" : 490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "source" : "147",
        "target" : "218",
        "EdgeBetweenness" : 410.0,
        "shared_name" : "Hik30-Rre33 (interacts with) nrsBACD",
        "shared_interaction" : "interacts with",
        "name" : "Hik30-Rre33 (interacts with) nrsBACD",
        "interaction" : "interacts with",
        "SUID" : 475,
        "BEND_MAP_ID" : 492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "474",
        "source" : "144",
        "target" : "160",
        "EdgeBetweenness" : 330.0,
        "shared_name" : "Hik27-Rre16 (interacts with) Mn2+",
        "shared_interaction" : "interacts with",
        "name" : "Hik27-Rre16 (interacts with) Mn2+",
        "interaction" : "interacts with",
        "SUID" : 474,
        "BEND_MAP_ID" : 488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "source" : "142",
        "target" : "214",
        "EdgeBetweenness" : 186.0,
        "shared_name" : "Hik20-Rre19 (interacts with) KDP",
        "shared_interaction" : "interacts with",
        "name" : "Hik20-Rre19 (interacts with) KDP",
        "interaction" : "interacts with",
        "SUID" : 473,
        "BEND_MAP_ID" : 484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "472",
        "source" : "140",
        "target" : "115",
        "EdgeBetweenness" : 280.0,
        "shared_name" : "�? (interacts with) Hik41-Sll1229",
        "shared_interaction" : "interacts with",
        "name" : "�? (interacts with) Hik41-Sll1229",
        "interaction" : "interacts with",
        "SUID" : 472,
        "BEND_MAP_ID" : 276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "source" : "140",
        "target" : "107",
        "EdgeBetweenness" : 828.333333333334,
        "shared_name" : "�? (interacts with) Hik33-Sll0698",
        "shared_interaction" : "interacts with",
        "name" : "�? (interacts with) Hik33-Sll0698",
        "interaction" : "interacts with",
        "SUID" : 471,
        "BEND_MAP_ID" : 269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "source" : "140",
        "target" : "108",
        "EdgeBetweenness" : 408.33333333333303,
        "shared_name" : "�? (interacts with) Hik34-Slr1285",
        "shared_interaction" : "interacts with",
        "name" : "�? (interacts with) Hik34-Slr1285",
        "interaction" : "interacts with",
        "SUID" : 470,
        "BEND_MAP_ID" : 267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "source" : "140",
        "target" : "89",
        "EdgeBetweenness" : 233.33333333333357,
        "shared_name" : "�? (interacts with) Hik16-Slr1805",
        "shared_interaction" : "interacts with",
        "name" : "�? (interacts with) Hik16-Slr1805",
        "interaction" : "interacts with",
        "SUID" : 469,
        "BEND_MAP_ID" : 213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "468",
        "source" : "131",
        "target" : "80",
        "EdgeBetweenness" : 305.0,
        "shared_name" : "磷酸�? (interacts with) Hik7-Sll0337",
        "shared_interaction" : "interacts with",
        "name" : "磷酸�? (interacts with) Hik7-Sll0337",
        "interaction" : "interacts with",
        "SUID" : 468,
        "BEND_MAP_ID" : 192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "source" : "129",
        "target" : "115",
        "EdgeBetweenness" : 600.6666666666665,
        "shared_name" : "氧化 (interacts with) Hik41-Sll1229",
        "shared_interaction" : "interacts with",
        "name" : "氧化 (interacts with) Hik41-Sll1229",
        "interaction" : "interacts with",
        "SUID" : 467,
        "BEND_MAP_ID" : 277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "466",
        "source" : "129",
        "target" : "107",
        "EdgeBetweenness" : 1949.5,
        "shared_name" : "氧化 (interacts with) Hik33-Sll0698",
        "shared_interaction" : "interacts with",
        "name" : "氧化 (interacts with) Hik33-Sll0698",
        "interaction" : "interacts with",
        "SUID" : 466,
        "BEND_MAP_ID" : 275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "source" : "129",
        "target" : "108",
        "EdgeBetweenness" : 891.1666666666675,
        "shared_name" : "氧化 (interacts with) Hik34-Slr1285",
        "shared_interaction" : "interacts with",
        "name" : "氧化 (interacts with) Hik34-Slr1285",
        "interaction" : "interacts with",
        "SUID" : 465,
        "BEND_MAP_ID" : 273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "source" : "129",
        "target" : "89",
        "EdgeBetweenness" : 538.5,
        "shared_name" : "氧化 (interacts with) Hik16-Slr1805",
        "shared_interaction" : "interacts with",
        "name" : "氧化 (interacts with) Hik16-Slr1805",
        "interaction" : "interacts with",
        "SUID" : 464,
        "BEND_MAP_ID" : 211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "source" : "129",
        "target" : "76",
        "EdgeBetweenness" : 227.16666666666688,
        "shared_name" : "氧化 (interacts with) Hik3-Sll1124",
        "shared_interaction" : "interacts with",
        "name" : "氧化 (interacts with) Hik3-Sll1124",
        "interaction" : "interacts with",
        "SUID" : 463,
        "BEND_MAP_ID" : 187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "source" : "126",
        "target" : "83",
        "EdgeBetweenness" : 196.0,
        "shared_name" : "高渗 (interacts with) Hik10-Slr0533",
        "shared_interaction" : "interacts with",
        "name" : "高渗 (interacts with) Hik10-Slr0533",
        "interaction" : "interacts with",
        "SUID" : 462,
        "BEND_MAP_ID" : 201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "source" : "126",
        "target" : "75",
        "EdgeBetweenness" : 252.0,
        "shared_name" : "高渗 (interacts with) Hik2-Slr1147",
        "shared_interaction" : "interacts with",
        "name" : "高渗 (interacts with) Hik2-Slr1147",
        "interaction" : "interacts with",
        "SUID" : 461,
        "BEND_MAP_ID" : 181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "source" : "124",
        "target" : "199",
        "EdgeBetweenness" : 54.0,
        "shared_name" : "光照 (interacts with) Hik47-Slr6041",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik47-Slr6041",
        "interaction" : "interacts with",
        "SUID" : 460,
        "BEND_MAP_ID" : 450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "source" : "124",
        "target" : "104",
        "EdgeBetweenness" : 348.7499999999999,
        "shared_name" : "光照 (interacts with) Hik31-Sll0790",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik31-Sll0790",
        "interaction" : "interacts with",
        "SUID" : 459,
        "BEND_MAP_ID" : 448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "source" : "124",
        "target" : "118",
        "EdgeBetweenness" : 78.74999999999999,
        "shared_name" : "光照 (interacts with) Hik44-Slr1212",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik44-Slr1212",
        "interaction" : "interacts with",
        "SUID" : 458,
        "BEND_MAP_ID" : 278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "source" : "124",
        "target" : "107",
        "EdgeBetweenness" : 618.75,
        "shared_name" : "光照 (interacts with) Hik33-Sll0698",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik33-Sll0698",
        "interaction" : "interacts with",
        "SUID" : 457,
        "BEND_MAP_ID" : 270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "source" : "124",
        "target" : "109",
        "EdgeBetweenness" : 69.74999999999997,
        "shared_name" : "光照 (interacts with) Hik35-Slr0473",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik35-Slr0473",
        "interaction" : "interacts with",
        "SUID" : 456,
        "BEND_MAP_ID" : 268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "source" : "124",
        "target" : "106",
        "EdgeBetweenness" : 96.75000000000006,
        "shared_name" : "光照 (interacts with) Hik32-Sll1475",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik32-Sll1475",
        "interaction" : "interacts with",
        "SUID" : 455,
        "BEND_MAP_ID" : 265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "454",
        "source" : "124",
        "target" : "105",
        "EdgeBetweenness" : 96.75000000000006,
        "shared_name" : "光照 (interacts with) Hik32-Sll1473",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik32-Sll1473",
        "interaction" : "interacts with",
        "SUID" : 454,
        "BEND_MAP_ID" : 264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "source" : "124",
        "target" : "97",
        "EdgeBetweenness" : 117.0000000000001,
        "shared_name" : "光照 (interacts with) Hik24-Slr1969",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik24-Slr1969",
        "interaction" : "interacts with",
        "SUID" : 453,
        "BEND_MAP_ID" : 253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "source" : "124",
        "target" : "76",
        "EdgeBetweenness" : 69.74999999999997,
        "shared_name" : "光照 (interacts with) Hik3-Sll1124",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik3-Sll1124",
        "interaction" : "interacts with",
        "SUID" : 452,
        "BEND_MAP_ID" : 188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "source" : "124",
        "target" : "74",
        "EdgeBetweenness" : 123.7500000000001,
        "shared_name" : "光照 (interacts with) Hik1-Slr1393",
        "shared_interaction" : "interacts with",
        "name" : "光照 (interacts with) Hik1-Slr1393",
        "interaction" : "interacts with",
        "SUID" : 451,
        "BEND_MAP_ID" : 177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "source" : "123",
        "target" : "189",
        "EdgeBetweenness" : 53.106589147286826,
        "shared_name" : "Sll5060 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Sll5060 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 450,
        "BEND_MAP_ID" : 443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "source" : "123",
        "target" : "196",
        "EdgeBetweenness" : 53.22222222222223,
        "shared_name" : "Sll5060 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Sll5060 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 449,
        "BEND_MAP_ID" : 393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "source" : "122",
        "target" : "189",
        "EdgeBetweenness" : 52.106589147286826,
        "shared_name" : "Sll1334  (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Sll1334  (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 448,
        "BEND_MAP_ID" : 442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "source" : "122",
        "target" : "172",
        "EdgeBetweenness" : 56.0,
        "shared_name" : "Sll1334  (interacts with) 黑暗中的成长优势",
        "shared_interaction" : "interacts with",
        "name" : "Sll1334  (interacts with) 黑暗中的成长优势",
        "interaction" : "interacts with",
        "SUID" : 447,
        "BEND_MAP_ID" : 299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "source" : "121",
        "target" : "190",
        "EdgeBetweenness" : 128.4335839598996,
        "shared_name" : "Hik47-Slr6041  (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik47-Slr6041  (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 446,
        "BEND_MAP_ID" : 441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "source" : "121",
        "target" : "195",
        "EdgeBetweenness" : 128.30952380952368,
        "shared_name" : "Hik47-Slr6041  (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik47-Slr6041  (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 445,
        "BEND_MAP_ID" : 392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "source" : "121",
        "target" : "169",
        "EdgeBetweenness" : 145.5,
        "shared_name" : "Hik47-Slr6041  (interacts with) 分割缺陷",
        "shared_interaction" : "interacts with",
        "name" : "Hik47-Slr6041  (interacts with) 分割缺陷",
        "interaction" : "interacts with",
        "SUID" : 444,
        "BEND_MAP_ID" : 297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "source" : "120",
        "target" : "189",
        "EdgeBetweenness" : 50.106589147286826,
        "shared_name" : "Hik46-Slr6001 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik46-Slr6001 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 443,
        "BEND_MAP_ID" : 440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "442",
        "source" : "120",
        "target" : "196",
        "EdgeBetweenness" : 50.22222222222223,
        "shared_name" : "Hik46-Slr6001 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik46-Slr6001 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 442,
        "BEND_MAP_ID" : 391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "source" : "120",
        "target" : "154",
        "EdgeBetweenness" : 54.0,
        "shared_name" : "Hik46-Slr6001 (interacts with) Hik46-Rre16",
        "shared_interaction" : "interacts with",
        "name" : "Hik46-Slr6001 (interacts with) Hik46-Rre16",
        "interaction" : "interacts with",
        "SUID" : 441,
        "BEND_MAP_ID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "source" : "119",
        "target" : "189",
        "EdgeBetweenness" : 49.106589147286826,
        "shared_name" : "Hik45-Sll5059  (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik45-Sll5059  (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 440,
        "BEND_MAP_ID" : 439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "source" : "118",
        "target" : "190",
        "EdgeBetweenness" : 66.26691729323312,
        "shared_name" : "Hik44-Slr1212 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik44-Slr1212 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 439,
        "BEND_MAP_ID" : 438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "source" : "118",
        "target" : "195",
        "EdgeBetweenness" : 54.89285714285714,
        "shared_name" : "Hik44-Slr1212 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik44-Slr1212 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 438,
        "BEND_MAP_ID" : 390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "source" : "117",
        "target" : "202",
        "EdgeBetweenness" : 48.333333333333336,
        "shared_name" : "Hik43-Slr0322 (interacts with) 趋光运动",
        "shared_interaction" : "interacts with",
        "name" : "Hik43-Slr0322 (interacts with) 趋光运动",
        "interaction" : "interacts with",
        "SUID" : 437,
        "BEND_MAP_ID" : 459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "source" : "117",
        "target" : "189",
        "EdgeBetweenness" : 47.106589147286826,
        "shared_name" : "Hik43-Slr0322 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik43-Slr0322 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 436,
        "BEND_MAP_ID" : 437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "source" : "117",
        "target" : "196",
        "EdgeBetweenness" : 47.22222222222223,
        "shared_name" : "Hik43-Slr0322 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik43-Slr0322 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 435,
        "BEND_MAP_ID" : 389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "source" : "117",
        "target" : "171",
        "EdgeBetweenness" : 49.0,
        "shared_name" : "Hik43-Slr0322 (interacts with) 非运动�?�的",
        "shared_interaction" : "interacts with",
        "name" : "Hik43-Slr0322 (interacts with) 非运动�?�的",
        "interaction" : "interacts with",
        "SUID" : 434,
        "BEND_MAP_ID" : 296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "source" : "116",
        "target" : "189",
        "EdgeBetweenness" : 46.106589147286826,
        "shared_name" : "Hik42-Sll1555 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik42-Sll1555 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 433,
        "BEND_MAP_ID" : 436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "source" : "116",
        "target" : "196",
        "EdgeBetweenness" : 46.22222222222223,
        "shared_name" : "Hik42-Sll1555 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik42-Sll1555 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 432,
        "BEND_MAP_ID" : 388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "source" : "115",
        "target" : "222",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "Hik41-Sll1229 (interacts with) sll0967和sll0939",
        "shared_interaction" : "interacts with",
        "name" : "Hik41-Sll1229 (interacts with) sll0967和sll0939",
        "interaction" : "interacts with",
        "SUID" : 431,
        "BEND_MAP_ID" : 500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "source" : "115",
        "target" : "189",
        "EdgeBetweenness" : 99.77325581395344,
        "shared_name" : "Hik41-Sll1229 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik41-Sll1229 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 430,
        "BEND_MAP_ID" : 435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "source" : "115",
        "target" : "196",
        "EdgeBetweenness" : 281.2222222222222,
        "shared_name" : "Hik41-Sll1229 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik41-Sll1229 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 429,
        "BEND_MAP_ID" : 387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "source" : "115",
        "target" : "153",
        "EdgeBetweenness" : 285.0,
        "shared_name" : "Hik41-Sll1229 (interacts with) Hik41-Rre17",
        "shared_interaction" : "interacts with",
        "name" : "Hik41-Sll1229 (interacts with) Hik41-Rre17",
        "interaction" : "interacts with",
        "SUID" : 428,
        "BEND_MAP_ID" : 240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "source" : "114",
        "target" : "189",
        "EdgeBetweenness" : 44.106589147286826,
        "shared_name" : "Hik40-Slr2099 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik40-Slr2099 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 427,
        "BEND_MAP_ID" : 434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "source" : "114",
        "target" : "196",
        "EdgeBetweenness" : 44.22222222222223,
        "shared_name" : "Hik40-Slr2099 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik40-Slr2099 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 426,
        "BEND_MAP_ID" : 386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "source" : "113",
        "target" : "189",
        "EdgeBetweenness" : 43.106589147286826,
        "shared_name" : "Hik39-Sll1296 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik39-Sll1296 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 425,
        "BEND_MAP_ID" : 433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "source" : "113",
        "target" : "196",
        "EdgeBetweenness" : 43.22222222222223,
        "shared_name" : "Hik39-Sll1296 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik39-Sll1296 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 424,
        "BEND_MAP_ID" : 385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "source" : "112",
        "target" : "189",
        "EdgeBetweenness" : 42.106589147286826,
        "shared_name" : "Hik38-Slr1400 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik38-Slr1400 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 423,
        "BEND_MAP_ID" : 432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "source" : "112",
        "target" : "196",
        "EdgeBetweenness" : 42.22222222222223,
        "shared_name" : "Hik38-Slr1400 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik38-Slr1400 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 422,
        "BEND_MAP_ID" : 384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "source" : "111",
        "target" : "189",
        "EdgeBetweenness" : 41.106589147286826,
        "shared_name" : "Hik37-Sll0094 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik37-Sll0094 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 421,
        "BEND_MAP_ID" : 431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "source" : "111",
        "target" : "195",
        "EdgeBetweenness" : 41.14285714285714,
        "shared_name" : "Hik37-Sll0094 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik37-Sll0094 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 420,
        "BEND_MAP_ID" : 383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "source" : "110",
        "target" : "202",
        "EdgeBetweenness" : 41.333333333333336,
        "shared_name" : "Hik36-Slr0073 (interacts with) 趋光运动",
        "shared_interaction" : "interacts with",
        "name" : "Hik36-Slr0073 (interacts with) 趋光运动",
        "interaction" : "interacts with",
        "SUID" : 419,
        "BEND_MAP_ID" : 458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "source" : "110",
        "target" : "189",
        "EdgeBetweenness" : 40.106589147286826,
        "shared_name" : "Hik36-Slr0073 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik36-Slr0073 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 418,
        "BEND_MAP_ID" : 430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "source" : "110",
        "target" : "171",
        "EdgeBetweenness" : 42.0,
        "shared_name" : "Hik36-Slr0073 (interacts with) 非运动�?�的",
        "shared_interaction" : "interacts with",
        "name" : "Hik36-Slr0073 (interacts with) 非运动�?�的",
        "interaction" : "interacts with",
        "SUID" : 417,
        "BEND_MAP_ID" : 295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "source" : "110",
        "target" : "152",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "Hik36-Slr0073 (interacts with) Hik36-Rre19",
        "shared_interaction" : "interacts with",
        "name" : "Hik36-Slr0073 (interacts with) Hik36-Rre19",
        "interaction" : "interacts with",
        "SUID" : 416,
        "BEND_MAP_ID" : 238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "source" : "109",
        "target" : "189",
        "EdgeBetweenness" : 48.106589147286805,
        "shared_name" : "Hik35-Slr0473 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik35-Slr0473 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 415,
        "BEND_MAP_ID" : 429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "source" : "109",
        "target" : "195",
        "EdgeBetweenness" : 45.89285714285714,
        "shared_name" : "Hik35-Slr0473 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik35-Slr0473 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 414,
        "BEND_MAP_ID" : 382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "source" : "108",
        "target" : "211",
        "EdgeBetweenness" : 364.0,
        "shared_name" : "Hik34-Slr1285 (interacts with) htpG",
        "shared_interaction" : "interacts with",
        "name" : "Hik34-Slr1285 (interacts with) htpG",
        "interaction" : "interacts with",
        "SUID" : 413,
        "BEND_MAP_ID" : 501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "source" : "108",
        "target" : "213",
        "EdgeBetweenness" : 364.0,
        "shared_name" : "Hik34-Slr1285 (interacts with) slr1963",
        "shared_interaction" : "interacts with",
        "name" : "Hik34-Slr1285 (interacts with) slr1963",
        "interaction" : "interacts with",
        "SUID" : 412,
        "BEND_MAP_ID" : 482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "source" : "108",
        "target" : "212",
        "EdgeBetweenness" : 364.0,
        "shared_name" : "Hik34-Slr1285 (interacts with) groESL1",
        "shared_interaction" : "interacts with",
        "name" : "Hik34-Slr1285 (interacts with) groESL1",
        "interaction" : "interacts with",
        "SUID" : 411,
        "BEND_MAP_ID" : 480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "source" : "108",
        "target" : "211",
        "EdgeBetweenness" : 364.0,
        "shared_name" : "Hik34-Slr1285 (interacts with) htpG",
        "shared_interaction" : "interacts with",
        "name" : "Hik34-Slr1285 (interacts with) htpG",
        "interaction" : "interacts with",
        "SUID" : 410,
        "BEND_MAP_ID" : 478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "source" : "108",
        "target" : "189",
        "EdgeBetweenness" : 121.43992248062023,
        "shared_name" : "Hik34-Slr1285 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik34-Slr1285 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 409,
        "BEND_MAP_ID" : 428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "source" : "108",
        "target" : "195",
        "EdgeBetweenness" : 124.47619047619038,
        "shared_name" : "Hik34-Slr1285 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik34-Slr1285 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 408,
        "BEND_MAP_ID" : 381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "source" : "108",
        "target" : "151",
        "EdgeBetweenness" : 364.0,
        "shared_name" : "Hik34-Slr1285 (interacts with) Hik34-Rre1",
        "shared_interaction" : "interacts with",
        "name" : "Hik34-Slr1285 (interacts with) Hik34-Rre1",
        "interaction" : "interacts with",
        "SUID" : 407,
        "BEND_MAP_ID" : 236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "406",
        "source" : "107",
        "target" : "227",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) ndnblA2",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) ndnblA2",
        "interaction" : "interacts with",
        "SUID" : 406,
        "BEND_MAP_ID" : 511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "source" : "107",
        "target" : "226",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) nblA1",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) nblA1",
        "interaction" : "interacts with",
        "SUID" : 405,
        "BEND_MAP_ID" : 509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "source" : "107",
        "target" : "225",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) pgr5",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) pgr5",
        "interaction" : "interacts with",
        "SUID" : 404,
        "BEND_MAP_ID" : 507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "source" : "107",
        "target" : "224",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) hli",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) hli",
        "interaction" : "interacts with",
        "SUID" : 403,
        "BEND_MAP_ID" : 505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "source" : "107",
        "target" : "223",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) ndhD2",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) ndhD2",
        "interaction" : "interacts with",
        "SUID" : 402,
        "BEND_MAP_ID" : 503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "source" : "107",
        "target" : "208",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with)  Ssl3451",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with)  Ssl3451",
        "interaction" : "interacts with",
        "SUID" : 401,
        "BEND_MAP_ID" : 473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "source" : "107",
        "target" : "207",
        "EdgeBetweenness" : 558.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) desB",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) desB",
        "interaction" : "interacts with",
        "SUID" : 400,
        "BEND_MAP_ID" : 471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "source" : "107",
        "target" : "190",
        "EdgeBetweenness" : 339.9335839598997,
        "shared_name" : "Hik33-Sll0698 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 399,
        "BEND_MAP_ID" : 427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "source" : "107",
        "target" : "195",
        "EdgeBetweenness" : 254.89285714285697,
        "shared_name" : "Hik33-Sll0698 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 398,
        "BEND_MAP_ID" : 380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "source" : "107",
        "target" : "170",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) 抑制的光自养生长",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) 抑制的光自养生长",
        "interaction" : "interacts with",
        "SUID" : 397,
        "BEND_MAP_ID" : 293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "source" : "107",
        "target" : "155",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) Hik33-Rre31",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) Hik33-Rre31",
        "interaction" : "interacts with",
        "SUID" : 396,
        "BEND_MAP_ID" : 244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "source" : "107",
        "target" : "150",
        "EdgeBetweenness" : 603.0,
        "shared_name" : "Hik33-Sll0698 (interacts with) Hik33-Rre26",
        "shared_interaction" : "interacts with",
        "name" : "Hik33-Sll0698 (interacts with) Hik33-Rre26",
        "interaction" : "interacts with",
        "SUID" : 395,
        "BEND_MAP_ID" : 234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "source" : "106",
        "target" : "189",
        "EdgeBetweenness" : 45.10658914728681,
        "shared_name" : "Hik32-Sll1475 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik32-Sll1475 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 394,
        "BEND_MAP_ID" : 426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "source" : "106",
        "target" : "195",
        "EdgeBetweenness" : 42.89285714285714,
        "shared_name" : "Hik32-Sll1475 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik32-Sll1475 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 393,
        "BEND_MAP_ID" : 379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "source" : "106",
        "target" : "149",
        "EdgeBetweenness" : 65.0,
        "shared_name" : "Hik32-Sll1475 (interacts with) Hik32-Rre38",
        "shared_interaction" : "interacts with",
        "name" : "Hik32-Sll1475 (interacts with) Hik32-Rre38",
        "interaction" : "interacts with",
        "SUID" : 392,
        "BEND_MAP_ID" : 232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "source" : "105",
        "target" : "189",
        "EdgeBetweenness" : 44.10658914728681,
        "shared_name" : "Hik32-Sll1473 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik32-Sll1473 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 391,
        "BEND_MAP_ID" : 425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "source" : "105",
        "target" : "195",
        "EdgeBetweenness" : 41.89285714285714,
        "shared_name" : "Hik32-Sll1473 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik32-Sll1473 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 390,
        "BEND_MAP_ID" : 378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "source" : "105",
        "target" : "149",
        "EdgeBetweenness" : 64.0,
        "shared_name" : "Hik32-Sll1473 (interacts with) Hik32-Rre38",
        "shared_interaction" : "interacts with",
        "name" : "Hik32-Sll1473 (interacts with) Hik32-Rre38",
        "interaction" : "interacts with",
        "SUID" : 389,
        "BEND_MAP_ID" : 231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "source" : "104",
        "target" : "206",
        "EdgeBetweenness" : 407.0,
        "shared_name" : "Hik31-Sll0790 (interacts with) icfG",
        "shared_interaction" : "interacts with",
        "name" : "Hik31-Sll0790 (interacts with) icfG",
        "interaction" : "interacts with",
        "SUID" : 388,
        "BEND_MAP_ID" : 466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "source" : "104",
        "target" : "205",
        "EdgeBetweenness" : 407.0,
        "shared_name" : "Hik31-Sll0790 (interacts with) 葡萄糖激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik31-Sll0790 (interacts with) 葡萄糖激�?",
        "interaction" : "interacts with",
        "SUID" : 387,
        "BEND_MAP_ID" : 464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "source" : "104",
        "target" : "190",
        "EdgeBetweenness" : 259.4335839598993,
        "shared_name" : "Hik31-Sll0790 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik31-Sll0790 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 386,
        "BEND_MAP_ID" : 424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "source" : "104",
        "target" : "195",
        "EdgeBetweenness" : 248.05952380952405,
        "shared_name" : "Hik31-Sll0790 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik31-Sll0790 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 385,
        "BEND_MAP_ID" : 377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "source" : "104",
        "target" : "169",
        "EdgeBetweenness" : 312.5,
        "shared_name" : "Hik31-Sll0790 (interacts with) 分割缺陷",
        "shared_interaction" : "interacts with",
        "name" : "Hik31-Sll0790 (interacts with) 分割缺陷",
        "interaction" : "interacts with",
        "SUID" : 384,
        "BEND_MAP_ID" : 291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "source" : "104",
        "target" : "148",
        "EdgeBetweenness" : 814.0,
        "shared_name" : "Hik31-Sll0790 (interacts with) Hik31-Rre34",
        "shared_interaction" : "interacts with",
        "name" : "Hik31-Sll0790 (interacts with) Hik31-Rre34",
        "interaction" : "interacts with",
        "SUID" : 383,
        "BEND_MAP_ID" : 229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "source" : "103",
        "target" : "190",
        "EdgeBetweenness" : 124.26691729323308,
        "shared_name" : "Hik30-Sll0798 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik30-Sll0798 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 382,
        "BEND_MAP_ID" : 423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "source" : "103",
        "target" : "195",
        "EdgeBetweenness" : 124.14285714285715,
        "shared_name" : "Hik30-Sll0798 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik30-Sll0798 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 381,
        "BEND_MAP_ID" : 376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "source" : "103",
        "target" : "147",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "Hik30-Sll0798 (interacts with) Hik30-Rre33",
        "shared_interaction" : "interacts with",
        "name" : "Hik30-Sll0798 (interacts with) Hik30-Rre33",
        "interaction" : "interacts with",
        "SUID" : 380,
        "BEND_MAP_ID" : 227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "source" : "102",
        "target" : "189",
        "EdgeBetweenness" : 32.106589147286826,
        "shared_name" : "Hik29-Slr0311 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik29-Slr0311 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 379,
        "BEND_MAP_ID" : 422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "source" : "102",
        "target" : "195",
        "EdgeBetweenness" : 32.14285714285714,
        "shared_name" : "Hik29-Slr0311 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik29-Slr0311 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 378,
        "BEND_MAP_ID" : 375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "source" : "102",
        "target" : "146",
        "EdgeBetweenness" : 36.0,
        "shared_name" : "Hik29-Slr0311 (interacts with) Hik29-Rre14",
        "shared_interaction" : "interacts with",
        "name" : "Hik29-Slr0311 (interacts with) Hik29-Rre14",
        "interaction" : "interacts with",
        "SUID" : 377,
        "BEND_MAP_ID" : 225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "source" : "102",
        "target" : "145",
        "EdgeBetweenness" : 36.0,
        "shared_name" : "Hik29-Slr0311 (interacts with) Hik29-Rre38",
        "shared_interaction" : "interacts with",
        "name" : "Hik29-Slr0311 (interacts with) Hik29-Rre38",
        "interaction" : "interacts with",
        "SUID" : 376,
        "BEND_MAP_ID" : 223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "source" : "101",
        "target" : "190",
        "EdgeBetweenness" : 74.26691729323308,
        "shared_name" : "Hik28-Sll0474 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik28-Sll0474 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 375,
        "BEND_MAP_ID" : 421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "source" : "101",
        "target" : "195",
        "EdgeBetweenness" : 52.64285714285714,
        "shared_name" : "Hik28-Sll0474 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik28-Sll0474 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 374,
        "BEND_MAP_ID" : 374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "source" : "100",
        "target" : "190",
        "EdgeBetweenness" : 194.26691729323312,
        "shared_name" : "Hik27-Slr0640 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik27-Slr0640 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 373,
        "BEND_MAP_ID" : 420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "source" : "100",
        "target" : "195",
        "EdgeBetweenness" : 194.14285714285714,
        "shared_name" : "Hik27-Slr0640 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik27-Slr0640 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 372,
        "BEND_MAP_ID" : 373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "source" : "100",
        "target" : "144",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "Hik27-Slr0640 (interacts with) Hik27-Rre16",
        "shared_interaction" : "interacts with",
        "name" : "Hik27-Slr0640 (interacts with) Hik27-Rre16",
        "interaction" : "interacts with",
        "SUID" : 371,
        "BEND_MAP_ID" : 221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "source" : "99",
        "target" : "189",
        "EdgeBetweenness" : 57.77325581395352,
        "shared_name" : "Hik26-Slr0484 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik26-Slr0484 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 370,
        "BEND_MAP_ID" : 419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "source" : "99",
        "target" : "195",
        "EdgeBetweenness" : 50.64285714285714,
        "shared_name" : "Hik26-Slr0484 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik26-Slr0484 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 369,
        "BEND_MAP_ID" : 372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "source" : "98",
        "target" : "189",
        "EdgeBetweenness" : 28.106589147286822,
        "shared_name" : "Hik25-Slr0222 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik25-Slr0222 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 368,
        "BEND_MAP_ID" : 418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "source" : "98",
        "target" : "196",
        "EdgeBetweenness" : 28.222222222222225,
        "shared_name" : "Hik25-Slr0222 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik25-Slr0222 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 367,
        "BEND_MAP_ID" : 371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "source" : "97",
        "target" : "189",
        "EdgeBetweenness" : 36.10658914728683,
        "shared_name" : "Hik24-Slr1969 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik24-Slr1969 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 366,
        "BEND_MAP_ID" : 417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "97",
        "target" : "196",
        "EdgeBetweenness" : 81.22222222222223,
        "shared_name" : "Hik24-Slr1969 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik24-Slr1969 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 365,
        "BEND_MAP_ID" : 370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "source" : "96",
        "target" : "189",
        "EdgeBetweenness" : 26.106589147286822,
        "shared_name" : "Hik23-Slr1324 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik23-Slr1324 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 364,
        "BEND_MAP_ID" : 416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "source" : "96",
        "target" : "196",
        "EdgeBetweenness" : 26.222222222222225,
        "shared_name" : "Hik23-Slr1324 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik23-Slr1324 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 363,
        "BEND_MAP_ID" : 369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "source" : "95",
        "target" : "189",
        "EdgeBetweenness" : 202.1065891472868,
        "shared_name" : "Hik22-Slr2104 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik22-Slr2104 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 362,
        "BEND_MAP_ID" : 415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "source" : "95",
        "target" : "196",
        "EdgeBetweenness" : 202.2222222222222,
        "shared_name" : "Hik22-Slr2104 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik22-Slr2104 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 361,
        "BEND_MAP_ID" : 368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "source" : "94",
        "target" : "190",
        "EdgeBetweenness" : 24.266917293233085,
        "shared_name" : "Hik21-Slr2098 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik21-Slr2098 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 360,
        "BEND_MAP_ID" : 414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "94",
        "target" : "196",
        "EdgeBetweenness" : 24.222222222222225,
        "shared_name" : "Hik21-Slr2098 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik21-Slr2098 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 359,
        "BEND_MAP_ID" : 367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "source" : "94",
        "target" : "143",
        "EdgeBetweenness" : 28.0,
        "shared_name" : "Hik21-Slr2098 (interacts with) Hik21-Rre20",
        "shared_interaction" : "interacts with",
        "name" : "Hik21-Slr2098 (interacts with) Hik21-Rre20",
        "interaction" : "interacts with",
        "SUID" : 358,
        "BEND_MAP_ID" : 219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "source" : "93",
        "target" : "190",
        "EdgeBetweenness" : 110.26691729323308,
        "shared_name" : "Hik20-Sll1590 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik20-Sll1590 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 357,
        "BEND_MAP_ID" : 413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "source" : "93",
        "target" : "195",
        "EdgeBetweenness" : 110.14285714285715,
        "shared_name" : "Hik20-Sll1590 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik20-Sll1590 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 356,
        "BEND_MAP_ID" : 366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "source" : "93",
        "target" : "142",
        "EdgeBetweenness" : 228.0,
        "shared_name" : "Hik20-Sll1590 (interacts with) Hik20-Rre19",
        "shared_interaction" : "interacts with",
        "name" : "Hik20-Sll1590 (interacts with) Hik20-Rre19",
        "interaction" : "interacts with",
        "SUID" : 355,
        "BEND_MAP_ID" : 217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "source" : "92",
        "target" : "207",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "Hik19-Sll1905 (interacts with) desB",
        "shared_interaction" : "interacts with",
        "name" : "Hik19-Sll1905 (interacts with) desB",
        "interaction" : "interacts with",
        "SUID" : 354,
        "BEND_MAP_ID" : 470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "source" : "92",
        "target" : "189",
        "EdgeBetweenness" : 50.7732558139535,
        "shared_name" : "Hik19-Sll1905 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik19-Sll1905 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 353,
        "BEND_MAP_ID" : 412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "source" : "92",
        "target" : "196",
        "EdgeBetweenness" : 108.22222222222223,
        "shared_name" : "Hik19-Sll1905 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik19-Sll1905 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 352,
        "BEND_MAP_ID" : 365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "source" : "92",
        "target" : "141",
        "EdgeBetweenness" : 112.0,
        "shared_name" : "Hik19-Sll1905 (interacts with) Hik19-Rre41",
        "shared_interaction" : "interacts with",
        "name" : "Hik19-Sll1905 (interacts with) Hik19-Rre41",
        "interaction" : "interacts with",
        "SUID" : 351,
        "BEND_MAP_ID" : 215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "source" : "91",
        "target" : "202",
        "EdgeBetweenness" : 22.333333333333332,
        "shared_name" : "Hik18-Sll0043 (interacts with) 趋光运动",
        "shared_interaction" : "interacts with",
        "name" : "Hik18-Sll0043 (interacts with) 趋光运动",
        "interaction" : "interacts with",
        "SUID" : 350,
        "BEND_MAP_ID" : 457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "source" : "91",
        "target" : "189",
        "EdgeBetweenness" : 21.106589147286822,
        "shared_name" : "Hik18-Sll0043 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik18-Sll0043 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 349,
        "BEND_MAP_ID" : 411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "source" : "91",
        "target" : "196",
        "EdgeBetweenness" : 21.222222222222225,
        "shared_name" : "Hik18-Sll0043 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik18-Sll0043 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 348,
        "BEND_MAP_ID" : 364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "91",
        "target" : "168",
        "EdgeBetweenness" : 25.0,
        "shared_name" : "Hik18-Sll0043 (interacts with) 负趋光�??",
        "shared_interaction" : "interacts with",
        "name" : "Hik18-Sll0043 (interacts with) 负趋光�??",
        "interaction" : "interacts with",
        "SUID" : 347,
        "BEND_MAP_ID" : 289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "source" : "90",
        "target" : "189",
        "EdgeBetweenness" : 20.106589147286822,
        "shared_name" : "Hik17-Sll1687 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik17-Sll1687 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 346,
        "BEND_MAP_ID" : 410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "source" : "89",
        "target" : "222",
        "EdgeBetweenness" : 139.0,
        "shared_name" : "Hik16-Slr1805 (interacts with) sll0967和sll0939",
        "shared_interaction" : "interacts with",
        "name" : "Hik16-Slr1805 (interacts with) sll0967和sll0939",
        "interaction" : "interacts with",
        "SUID" : 345,
        "BEND_MAP_ID" : 499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "source" : "89",
        "target" : "190",
        "EdgeBetweenness" : 136.26691729323312,
        "shared_name" : "Hik16-Slr1805 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik16-Slr1805 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 344,
        "BEND_MAP_ID" : 409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "source" : "89",
        "target" : "195",
        "EdgeBetweenness" : 83.97619047619048,
        "shared_name" : "Hik16-Slr1805 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik16-Slr1805 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 343,
        "BEND_MAP_ID" : 363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "source" : "89",
        "target" : "139",
        "EdgeBetweenness" : 259.0,
        "shared_name" : "Hik16-Slr1805 (interacts with) Rre17",
        "shared_interaction" : "interacts with",
        "name" : "Hik16-Slr1805 (interacts with) Rre17",
        "interaction" : "interacts with",
        "SUID" : 342,
        "BEND_MAP_ID" : 210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "source" : "88",
        "target" : "190",
        "EdgeBetweenness" : 18.266917293233085,
        "shared_name" : "Hik15-Sll1353 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik15-Sll1353 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 341,
        "BEND_MAP_ID" : 408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "source" : "88",
        "target" : "195",
        "EdgeBetweenness" : 18.142857142857142,
        "shared_name" : "Hik15-Sll1353 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik15-Sll1353 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 340,
        "BEND_MAP_ID" : 362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "source" : "88",
        "target" : "166",
        "EdgeBetweenness" : 20.0,
        "shared_name" : "Hik15-Sll1353 (interacts with) 细胞生存的必�?�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik15-Sll1353 (interacts with) 细胞生存的必�?�?",
        "interaction" : "interacts with",
        "SUID" : 339,
        "BEND_MAP_ID" : 287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "source" : "87",
        "target" : "189",
        "EdgeBetweenness" : 17.106589147286822,
        "shared_name" : "Hik14-Slr1759 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik14-Slr1759 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 338,
        "BEND_MAP_ID" : 407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "source" : "87",
        "target" : "196",
        "EdgeBetweenness" : 17.22222222222222,
        "shared_name" : "Hik14-Slr1759 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik14-Slr1759 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 337,
        "BEND_MAP_ID" : 361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "source" : "87",
        "target" : "167",
        "EdgeBetweenness" : 21.0,
        "shared_name" : "Hik14-Slr1759 (interacts with) �?定条件下的生长缺�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik14-Slr1759 (interacts with) �?定条件下的生长缺�?",
        "interaction" : "interacts with",
        "SUID" : 336,
        "BEND_MAP_ID" : 286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "source" : "87",
        "target" : "138",
        "EdgeBetweenness" : 21.0,
        "shared_name" : "Hik14-Slr1759 (interacts with) Rre8",
        "shared_interaction" : "interacts with",
        "name" : "Hik14-Slr1759 (interacts with) Rre8",
        "interaction" : "interacts with",
        "SUID" : 335,
        "BEND_MAP_ID" : 208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "source" : "86",
        "target" : "189",
        "EdgeBetweenness" : 16.106589147286822,
        "shared_name" : "Hik13-Sll1003 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik13-Sll1003 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 334,
        "BEND_MAP_ID" : 406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "source" : "86",
        "target" : "195",
        "EdgeBetweenness" : 16.142857142857146,
        "shared_name" : "Hik13-Sll1003 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik13-Sll1003 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 333,
        "BEND_MAP_ID" : 360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "86",
        "target" : "166",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "Hik13-Sll1003 (interacts with) 细胞生存的必�?�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik13-Sll1003 (interacts with) 细胞生存的必�?�?",
        "interaction" : "interacts with",
        "SUID" : 332,
        "BEND_MAP_ID" : 284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "source" : "86",
        "target" : "135",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "Hik13-Sll1003 (interacts with) Rre9",
        "shared_interaction" : "interacts with",
        "name" : "Hik13-Sll1003 (interacts with) Rre9",
        "interaction" : "interacts with",
        "SUID" : 331,
        "BEND_MAP_ID" : 206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "source" : "85",
        "target" : "190",
        "EdgeBetweenness" : 15.266917293233082,
        "shared_name" : "Hik12-Sll1672 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik12-Sll1672 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 330,
        "BEND_MAP_ID" : 405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "source" : "85",
        "target" : "196",
        "EdgeBetweenness" : 15.222222222222221,
        "shared_name" : "Hik12-Sll1672 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik12-Sll1672 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 329,
        "BEND_MAP_ID" : 359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "source" : "84",
        "target" : "189",
        "EdgeBetweenness" : 14.106589147286822,
        "shared_name" : "Hik11-Slr1414 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik11-Slr1414 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 328,
        "BEND_MAP_ID" : 404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "source" : "84",
        "target" : "195",
        "EdgeBetweenness" : 14.142857142857144,
        "shared_name" : "Hik11-Slr1414 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik11-Slr1414 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 327,
        "BEND_MAP_ID" : 358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "source" : "84",
        "target" : "137",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "Hik11-Slr1414 (interacts with) Rre19",
        "shared_interaction" : "interacts with",
        "name" : "Hik11-Slr1414 (interacts with) Rre19",
        "interaction" : "interacts with",
        "SUID" : 326,
        "BEND_MAP_ID" : 205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "source" : "83",
        "target" : "190",
        "EdgeBetweenness" : 69.26691729323308,
        "shared_name" : "Hik10-Slr0533 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik10-Slr0533 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 325,
        "BEND_MAP_ID" : 403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "source" : "83",
        "target" : "195",
        "EdgeBetweenness" : 41.14285714285714,
        "shared_name" : "Hik10-Slr0533 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik10-Slr0533 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 324,
        "BEND_MAP_ID" : 357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "source" : "83",
        "target" : "136",
        "EdgeBetweenness" : 73.0,
        "shared_name" : "Hik10-Slr0533 (interacts with) Rre3",
        "shared_interaction" : "interacts with",
        "name" : "Hik10-Slr0533 (interacts with) Rre3",
        "interaction" : "interacts with",
        "SUID" : 323,
        "BEND_MAP_ID" : 203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "source" : "82",
        "target" : "189",
        "EdgeBetweenness" : 12.106589147286822,
        "shared_name" : "Hik9-Slr0210 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik9-Slr0210 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 322,
        "BEND_MAP_ID" : 402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "source" : "82",
        "target" : "195",
        "EdgeBetweenness" : 12.142857142857144,
        "shared_name" : "Hik9-Slr0210 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik9-Slr0210 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 321,
        "BEND_MAP_ID" : 356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "source" : "82",
        "target" : "135",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Hik9-Slr0210 (interacts with) Rre9",
        "shared_interaction" : "interacts with",
        "name" : "Hik9-Slr0210 (interacts with) Rre9",
        "interaction" : "interacts with",
        "SUID" : 320,
        "BEND_MAP_ID" : 200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "source" : "81",
        "target" : "198",
        "EdgeBetweenness" : 142.0,
        "shared_name" : "Hik8-Sll0750 (interacts with) Gap1",
        "shared_interaction" : "interacts with",
        "name" : "Hik8-Sll0750 (interacts with) Gap1",
        "interaction" : "interacts with",
        "SUID" : 319,
        "BEND_MAP_ID" : 447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "source" : "81",
        "target" : "189",
        "EdgeBetweenness" : 138.1065891472868,
        "shared_name" : "Hik8-Sll0750 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik8-Sll0750 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 318,
        "BEND_MAP_ID" : 401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "source" : "81",
        "target" : "195",
        "EdgeBetweenness" : 138.14285714285714,
        "shared_name" : "Hik8-Sll0750 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik8-Sll0750 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 317,
        "BEND_MAP_ID" : 355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "source" : "81",
        "target" : "165",
        "EdgeBetweenness" : 142.0,
        "shared_name" : "Hik8-Sll0750 (interacts with) 光敏感：葡萄糖暗循环",
        "shared_interaction" : "interacts with",
        "name" : "Hik8-Sll0750 (interacts with) 光敏感：葡萄糖暗循环",
        "interaction" : "interacts with",
        "SUID" : 316,
        "BEND_MAP_ID" : 282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "source" : "81",
        "target" : "134",
        "EdgeBetweenness" : 142.0,
        "shared_name" : "Hik8-Sll0750 (interacts with) Rre12",
        "shared_interaction" : "interacts with",
        "name" : "Hik8-Sll0750 (interacts with) Rre12",
        "interaction" : "interacts with",
        "SUID" : 315,
        "BEND_MAP_ID" : 198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "source" : "80",
        "target" : "189",
        "EdgeBetweenness" : 71.10658914728681,
        "shared_name" : "Hik7-Sll0337 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik7-Sll0337 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 314,
        "BEND_MAP_ID" : 400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "source" : "80",
        "target" : "195",
        "EdgeBetweenness" : 71.14285714285715,
        "shared_name" : "Hik7-Sll0337 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik7-Sll0337 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 313,
        "BEND_MAP_ID" : 354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "source" : "80",
        "target" : "133",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "Hik7-Sll0337 (interacts with) Rre29",
        "shared_interaction" : "interacts with",
        "name" : "Hik7-Sll0337 (interacts with) Rre29",
        "interaction" : "interacts with",
        "SUID" : 312,
        "BEND_MAP_ID" : 196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "source" : "80",
        "target" : "132",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "Hik7-Sll0337 (interacts with) Rre5",
        "shared_interaction" : "interacts with",
        "name" : "Hik7-Sll0337 (interacts with) Rre5",
        "interaction" : "interacts with",
        "SUID" : 311,
        "BEND_MAP_ID" : 194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "source" : "79",
        "target" : "190",
        "EdgeBetweenness" : 9.266917293233082,
        "shared_name" : "Hik6-Sll1871 (interacts with) 膜蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik6-Sll1871 (interacts with) 膜蛋�?",
        "interaction" : "interacts with",
        "SUID" : 310,
        "BEND_MAP_ID" : 399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "source" : "79",
        "target" : "195",
        "EdgeBetweenness" : 9.142857142857142,
        "shared_name" : "Hik6-Sll1871 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik6-Sll1871 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 309,
        "BEND_MAP_ID" : 353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "source" : "78",
        "target" : "189",
        "EdgeBetweenness" : 8.106589147286822,
        "shared_name" : "Hik5-Sll1888 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik5-Sll1888 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 308,
        "BEND_MAP_ID" : 398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "source" : "78",
        "target" : "195",
        "EdgeBetweenness" : 8.142857142857142,
        "shared_name" : "Hik5-Sll1888 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik5-Sll1888 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 307,
        "BEND_MAP_ID" : 352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "source" : "78",
        "target" : "130",
        "EdgeBetweenness" : 12.0,
        "shared_name" : "Hik5-Sll1888 (interacts with) Rre42",
        "shared_interaction" : "interacts with",
        "name" : "Hik5-Sll1888 (interacts with) Rre42",
        "interaction" : "interacts with",
        "SUID" : 306,
        "BEND_MAP_ID" : 190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "source" : "77",
        "target" : "189",
        "EdgeBetweenness" : 7.1065891472868215,
        "shared_name" : "Hik4-Sll1228 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik4-Sll1228 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 305,
        "BEND_MAP_ID" : 397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "source" : "77",
        "target" : "196",
        "EdgeBetweenness" : 7.222222222222221,
        "shared_name" : "Hik4-Sll1228 (interacts with) 杂合组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik4-Sll1228 (interacts with) 杂合组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 304,
        "BEND_MAP_ID" : 351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "source" : "76",
        "target" : "189",
        "EdgeBetweenness" : 34.77325581395349,
        "shared_name" : "Hik3-Sll1124 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik3-Sll1124 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 303,
        "BEND_MAP_ID" : 396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "source" : "76",
        "target" : "195",
        "EdgeBetweenness" : 54.39285714285714,
        "shared_name" : "Hik3-Sll1124 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik3-Sll1124 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 302,
        "BEND_MAP_ID" : 349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "source" : "75",
        "target" : "189",
        "EdgeBetweenness" : 61.106589147286826,
        "shared_name" : "Hik2-Slr1147 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik2-Slr1147 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 301,
        "BEND_MAP_ID" : 395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "source" : "75",
        "target" : "195",
        "EdgeBetweenness" : 33.14285714285714,
        "shared_name" : "Hik2-Slr1147 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik2-Slr1147 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 300,
        "BEND_MAP_ID" : 348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "75",
        "target" : "128",
        "EdgeBetweenness" : 65.0,
        "shared_name" : "Hik2-Slr1147 (interacts with) Rre33",
        "shared_interaction" : "interacts with",
        "name" : "Hik2-Slr1147 (interacts with) Rre33",
        "interaction" : "interacts with",
        "SUID" : 299,
        "BEND_MAP_ID" : 185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "75",
        "target" : "127",
        "EdgeBetweenness" : 65.0,
        "shared_name" : "Hik2-Slr1147 (interacts with) Rre1",
        "shared_interaction" : "interacts with",
        "name" : "Hik2-Slr1147 (interacts with) Rre1",
        "interaction" : "interacts with",
        "SUID" : 298,
        "BEND_MAP_ID" : 183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "source" : "74",
        "target" : "189",
        "EdgeBetweenness" : 13.106589147286826,
        "shared_name" : "Hik1-Slr1393 (interacts with) 可溶性蛋�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik1-Slr1393 (interacts with) 可溶性蛋�?",
        "interaction" : "interacts with",
        "SUID" : 297,
        "BEND_MAP_ID" : 394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "74",
        "target" : "195",
        "EdgeBetweenness" : 10.892857142857144,
        "shared_name" : "Hik1-Slr1393 (interacts with) 仅传感器组氨酸激�?",
        "shared_interaction" : "interacts with",
        "name" : "Hik1-Slr1393 (interacts with) 仅传感器组氨酸激�?",
        "interaction" : "interacts with",
        "SUID" : 296,
        "BEND_MAP_ID" : 347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "source" : "74",
        "target" : "125",
        "EdgeBetweenness" : 62.0,
        "shared_name" : "Hik1-Slr1393 (interacts with) Rre10",
        "shared_interaction" : "interacts with",
        "name" : "Hik1-Slr1393 (interacts with) Rre10",
        "interaction" : "interacts with",
        "SUID" : 295,
        "BEND_MAP_ID" : 179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "73",
        "target" : "123",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Sll5060",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Sll5060",
        "interaction" : "interacts with",
        "SUID" : 294,
        "BEND_MAP_ID" : 175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "source" : "73",
        "target" : "122",
        "EdgeBetweenness" : 8.106589147286822,
        "shared_name" : "Histidine kinase (interacts with) Sll1334 ",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Sll1334 ",
        "interaction" : "interacts with",
        "SUID" : 293,
        "BEND_MAP_ID" : 173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "73",
        "target" : "121",
        "EdgeBetweenness" : 6.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik47-Slr6041 ",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik47-Slr6041 ",
        "interaction" : "interacts with",
        "SUID" : 292,
        "BEND_MAP_ID" : 171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "source" : "73",
        "target" : "120",
        "EdgeBetweenness" : 8.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik46-Slr6001",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik46-Slr6001",
        "interaction" : "interacts with",
        "SUID" : 291,
        "BEND_MAP_ID" : 169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "73",
        "target" : "119",
        "EdgeBetweenness" : 4.1065891472868215,
        "shared_name" : "Histidine kinase (interacts with) Hik45-Sll5059 ",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik45-Sll5059 ",
        "interaction" : "interacts with",
        "SUID" : 290,
        "BEND_MAP_ID" : 167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "source" : "73",
        "target" : "118",
        "EdgeBetweenness" : 4.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik44-Slr1212",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik44-Slr1212",
        "interaction" : "interacts with",
        "SUID" : 289,
        "BEND_MAP_ID" : 165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "73",
        "target" : "117",
        "EdgeBetweenness" : 7.662144702842378,
        "shared_name" : "Histidine kinase (interacts with) Hik43-Slr0322",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik43-Slr0322",
        "interaction" : "interacts with",
        "SUID" : 288,
        "BEND_MAP_ID" : 163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "source" : "73",
        "target" : "116",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik42-Sll1555",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik42-Sll1555",
        "interaction" : "interacts with",
        "SUID" : 287,
        "BEND_MAP_ID" : 161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "source" : "73",
        "target" : "115",
        "EdgeBetweenness" : 10.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik41-Sll1229",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik41-Sll1229",
        "interaction" : "interacts with",
        "SUID" : 286,
        "BEND_MAP_ID" : 159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "source" : "73",
        "target" : "114",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik40-Slr2099",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik40-Slr2099",
        "interaction" : "interacts with",
        "SUID" : 285,
        "BEND_MAP_ID" : 157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "source" : "73",
        "target" : "113",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik39-Sll1296",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik39-Sll1296",
        "interaction" : "interacts with",
        "SUID" : 284,
        "BEND_MAP_ID" : 155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "73",
        "target" : "112",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik38-Slr1400",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik38-Slr1400",
        "interaction" : "interacts with",
        "SUID" : 283,
        "BEND_MAP_ID" : 153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "source" : "73",
        "target" : "111",
        "EdgeBetweenness" : 4.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik37-Sll0094",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik37-Sll0094",
        "interaction" : "interacts with",
        "SUID" : 282,
        "BEND_MAP_ID" : 151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "source" : "73",
        "target" : "110",
        "EdgeBetweenness" : 11.439922480620154,
        "shared_name" : "Histidine kinase (interacts with) Hik36-Slr0073",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik36-Slr0073",
        "interaction" : "interacts with",
        "SUID" : 281,
        "BEND_MAP_ID" : 149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "source" : "73",
        "target" : "109",
        "EdgeBetweenness" : 4.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik35-Slr0473",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik35-Slr0473",
        "interaction" : "interacts with",
        "SUID" : 280,
        "BEND_MAP_ID" : 147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "source" : "73",
        "target" : "108",
        "EdgeBetweenness" : 20.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik34-Slr1285",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik34-Slr1285",
        "interaction" : "interacts with",
        "SUID" : 279,
        "BEND_MAP_ID" : 145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "source" : "73",
        "target" : "107",
        "EdgeBetweenness" : 42.40977443609023,
        "shared_name" : "Histidine kinase (interacts with) Hik33-Sll0698",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik33-Sll0698",
        "interaction" : "interacts with",
        "SUID" : 278,
        "BEND_MAP_ID" : 143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "source" : "73",
        "target" : "106",
        "EdgeBetweenness" : 6.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik32-Sll1475",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik32-Sll1475",
        "interaction" : "interacts with",
        "SUID" : 277,
        "BEND_MAP_ID" : 141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "source" : "73",
        "target" : "105",
        "EdgeBetweenness" : 6.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik32-Sll1473",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik32-Sll1473",
        "interaction" : "interacts with",
        "SUID" : 276,
        "BEND_MAP_ID" : 139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "73",
        "target" : "104",
        "EdgeBetweenness" : 22.409774436090224,
        "shared_name" : "Histidine kinase (interacts with) Hik31-Sll0790",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik31-Sll0790",
        "interaction" : "interacts with",
        "SUID" : 275,
        "BEND_MAP_ID" : 137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "source" : "73",
        "target" : "103",
        "EdgeBetweenness" : 16.409774436090228,
        "shared_name" : "Histidine kinase (interacts with) Hik30-Sll0798",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik30-Sll0798",
        "interaction" : "interacts with",
        "SUID" : 274,
        "BEND_MAP_ID" : 135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "source" : "73",
        "target" : "102",
        "EdgeBetweenness" : 12.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik29-Slr0311",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik29-Slr0311",
        "interaction" : "interacts with",
        "SUID" : 273,
        "BEND_MAP_ID" : 133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "source" : "73",
        "target" : "101",
        "EdgeBetweenness" : 4.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik28-Sll0474",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik28-Sll0474",
        "interaction" : "interacts with",
        "SUID" : 272,
        "BEND_MAP_ID" : 131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "source" : "73",
        "target" : "100",
        "EdgeBetweenness" : 12.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik27-Slr0640",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik27-Slr0640",
        "interaction" : "interacts with",
        "SUID" : 271,
        "BEND_MAP_ID" : 129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "source" : "73",
        "target" : "99",
        "EdgeBetweenness" : 4.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik26-Slr0484",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik26-Slr0484",
        "interaction" : "interacts with",
        "SUID" : 270,
        "BEND_MAP_ID" : 127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "source" : "73",
        "target" : "98",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik25-Slr0222",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik25-Slr0222",
        "interaction" : "interacts with",
        "SUID" : 269,
        "BEND_MAP_ID" : 125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "source" : "73",
        "target" : "97",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik24-Slr1969",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik24-Slr1969",
        "interaction" : "interacts with",
        "SUID" : 268,
        "BEND_MAP_ID" : 123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "source" : "73",
        "target" : "96",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik23-Slr1324",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik23-Slr1324",
        "interaction" : "interacts with",
        "SUID" : 267,
        "BEND_MAP_ID" : 121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "source" : "73",
        "target" : "95",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik22-Slr2104",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik22-Slr2104",
        "interaction" : "interacts with",
        "SUID" : 266,
        "BEND_MAP_ID" : 119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "source" : "73",
        "target" : "94",
        "EdgeBetweenness" : 8.489139515455305,
        "shared_name" : "Histidine kinase (interacts with) Hik21-Slr2098",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik21-Slr2098",
        "interaction" : "interacts with",
        "SUID" : 265,
        "BEND_MAP_ID" : 117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "source" : "73",
        "target" : "93",
        "EdgeBetweenness" : 12.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik20-Sll1590",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik20-Sll1590",
        "interaction" : "interacts with",
        "SUID" : 264,
        "BEND_MAP_ID" : 115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "source" : "73",
        "target" : "92",
        "EdgeBetweenness" : 10.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik19-Sll1905",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik19-Sll1905",
        "interaction" : "interacts with",
        "SUID" : 263,
        "BEND_MAP_ID" : 113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "source" : "73",
        "target" : "91",
        "EdgeBetweenness" : 9.662144702842378,
        "shared_name" : "Histidine kinase (interacts with) Hik18-Sll0043",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik18-Sll0043",
        "interaction" : "interacts with",
        "SUID" : 262,
        "BEND_MAP_ID" : 111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "source" : "73",
        "target" : "90",
        "EdgeBetweenness" : 4.1065891472868215,
        "shared_name" : "Histidine kinase (interacts with) Hik17-Sll1687",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik17-Sll1687",
        "interaction" : "interacts with",
        "SUID" : 261,
        "BEND_MAP_ID" : 109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "source" : "73",
        "target" : "89",
        "EdgeBetweenness" : 10.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik16-Slr1805",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik16-Slr1805",
        "interaction" : "interacts with",
        "SUID" : 260,
        "BEND_MAP_ID" : 107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "source" : "73",
        "target" : "88",
        "EdgeBetweenness" : 6.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik15-Sll1353",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik15-Sll1353",
        "interaction" : "interacts with",
        "SUID" : 259,
        "BEND_MAP_ID" : 105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "source" : "73",
        "target" : "87",
        "EdgeBetweenness" : 12.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik14-Slr1759",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik14-Slr1759",
        "interaction" : "interacts with",
        "SUID" : 258,
        "BEND_MAP_ID" : 103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "source" : "73",
        "target" : "86",
        "EdgeBetweenness" : 8.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik13-Sll1003",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik13-Sll1003",
        "interaction" : "interacts with",
        "SUID" : 257,
        "BEND_MAP_ID" : 101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "source" : "73",
        "target" : "85",
        "EdgeBetweenness" : 4.489139515455305,
        "shared_name" : "Histidine kinase (interacts with) Hik12-Sll1672",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik12-Sll1672",
        "interaction" : "interacts with",
        "SUID" : 256,
        "BEND_MAP_ID" : 99,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "source" : "73",
        "target" : "84",
        "EdgeBetweenness" : 8.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik11-Slr1414",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik11-Slr1414",
        "interaction" : "interacts with",
        "SUID" : 255,
        "BEND_MAP_ID" : 97,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "source" : "73",
        "target" : "83",
        "EdgeBetweenness" : 8.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik10-Slr0533",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik10-Slr0533",
        "interaction" : "interacts with",
        "SUID" : 254,
        "BEND_MAP_ID" : 95,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "source" : "73",
        "target" : "82",
        "EdgeBetweenness" : 6.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik9-Slr0210",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik9-Slr0210",
        "interaction" : "interacts with",
        "SUID" : 253,
        "BEND_MAP_ID" : 93,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "source" : "73",
        "target" : "81",
        "EdgeBetweenness" : 16.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik8-Sll0750",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik8-Sll0750",
        "interaction" : "interacts with",
        "SUID" : 252,
        "BEND_MAP_ID" : 91,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "73",
        "target" : "80",
        "EdgeBetweenness" : 12.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik7-Sll0337",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik7-Sll0337",
        "interaction" : "interacts with",
        "SUID" : 251,
        "BEND_MAP_ID" : 89,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "source" : "73",
        "target" : "79",
        "EdgeBetweenness" : 4.409774436090226,
        "shared_name" : "Histidine kinase (interacts with) Hik6-Sll1871",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik6-Sll1871",
        "interaction" : "interacts with",
        "SUID" : 250,
        "BEND_MAP_ID" : 87,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "source" : "73",
        "target" : "78",
        "EdgeBetweenness" : 8.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik5-Sll1888",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik5-Sll1888",
        "interaction" : "interacts with",
        "SUID" : 249,
        "BEND_MAP_ID" : 85,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "source" : "73",
        "target" : "77",
        "EdgeBetweenness" : 4.328811369509044,
        "shared_name" : "Histidine kinase (interacts with) Hik4-Sll1228",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik4-Sll1228",
        "interaction" : "interacts with",
        "SUID" : 248,
        "BEND_MAP_ID" : 83,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "source" : "73",
        "target" : "76",
        "EdgeBetweenness" : 4.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik3-Sll1124",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik3-Sll1124",
        "interaction" : "interacts with",
        "SUID" : 247,
        "BEND_MAP_ID" : 81,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "source" : "73",
        "target" : "75",
        "EdgeBetweenness" : 12.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik2-Slr1147",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik2-Slr1147",
        "interaction" : "interacts with",
        "SUID" : 246,
        "BEND_MAP_ID" : 79,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "source" : "73",
        "target" : "74",
        "EdgeBetweenness" : 8.249446290143965,
        "shared_name" : "Histidine kinase (interacts with) Hik1-Slr1393",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Hik1-Slr1393",
        "interaction" : "interacts with",
        "SUID" : 245,
        "BEND_MAP_ID" : 77,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "source" : "72",
        "target" : "194",
        "EdgeBetweenness" : 3.308970099667774,
        "shared_name" : "spK (interacts with) spkL-Sll0095",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) spkL-Sll0095",
        "interaction" : "interacts with",
        "SUID" : 244,
        "BEND_MAP_ID" : 528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "source" : "72",
        "target" : "188",
        "EdgeBetweenness" : 4.4526315789473685,
        "shared_name" : "spK (interacts with) SpkK-Slr1919 ",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) SpkK-Slr1919 ",
        "interaction" : "interacts with",
        "SUID" : 243,
        "BEND_MAP_ID" : 527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "72",
        "target" : "193",
        "EdgeBetweenness" : 3.308970099667774,
        "shared_name" : "spK (interacts with) SpkJ-Slr0889",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) SpkJ-Slr0889",
        "interaction" : "interacts with",
        "SUID" : 242,
        "BEND_MAP_ID" : 526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "source" : "72",
        "target" : "192",
        "EdgeBetweenness" : 3.4526315789473685,
        "shared_name" : "spK (interacts with) SpkI-Sll1770",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) SpkI-Sll1770",
        "interaction" : "interacts with",
        "SUID" : 241,
        "BEND_MAP_ID" : 525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "72",
        "target" : "191",
        "EdgeBetweenness" : 3.308970099667774,
        "shared_name" : "spK (interacts with) SpkH-Sll0005",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) SpkH-Sll0005",
        "interaction" : "interacts with",
        "SUID" : 240,
        "BEND_MAP_ID" : 524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "source" : "72",
        "target" : "178",
        "EdgeBetweenness" : 9.308970099667773,
        "shared_name" : "spK (interacts with) spkG-Slr0152",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) spkG-Slr0152",
        "interaction" : "interacts with",
        "SUID" : 239,
        "BEND_MAP_ID" : 523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "source" : "72",
        "target" : "187",
        "EdgeBetweenness" : 4.4526315789473685,
        "shared_name" : "spK (interacts with) spkF-Slr1225",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) spkF-Slr1225",
        "interaction" : "interacts with",
        "SUID" : 238,
        "BEND_MAP_ID" : 522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "source" : "72",
        "target" : "181",
        "EdgeBetweenness" : 6.308970099667773,
        "shared_name" : "spK (interacts with) spkE-Slr1443",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) spkE-Slr1443",
        "interaction" : "interacts with",
        "SUID" : 237,
        "BEND_MAP_ID" : 521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "source" : "72",
        "target" : "176",
        "EdgeBetweenness" : 9.452631578947368,
        "shared_name" : "spK (interacts with) spkD-Sll0776",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) spkD-Sll0776",
        "interaction" : "interacts with",
        "SUID" : 236,
        "BEND_MAP_ID" : 520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "source" : "72",
        "target" : "185",
        "EdgeBetweenness" : 4.4526315789473685,
        "shared_name" : "spK (interacts with) spkC-Slr0599",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) spkC-Slr0599",
        "interaction" : "interacts with",
        "SUID" : 235,
        "BEND_MAP_ID" : 519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "72",
        "target" : "175",
        "EdgeBetweenness" : 58.808970099667775,
        "shared_name" : "spK (interacts with) SpkB-Slr1697",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) SpkB-Slr1697",
        "interaction" : "interacts with",
        "SUID" : 234,
        "BEND_MAP_ID" : 518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "source" : "72",
        "target" : "173",
        "EdgeBetweenness" : 4.808970099667774,
        "shared_name" : "spK (interacts with) SpkA-Sll1574&1575",
        "shared_interaction" : "interacts with",
        "name" : "spK (interacts with) SpkA-Sll1574&1575",
        "interaction" : "interacts with",
        "SUID" : 233,
        "BEND_MAP_ID" : 517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "source" : "71",
        "target" : "73",
        "EdgeBetweenness" : 109.57405140758873,
        "shared_name" : "Synechocystis (interacts with) Histidine kinase",
        "shared_interaction" : "interacts with",
        "name" : "Synechocystis (interacts with) Histidine kinase",
        "interaction" : "interacts with",
        "SUID" : 232,
        "BEND_MAP_ID" : 75,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "source" : "71",
        "target" : "72",
        "EdgeBetweenness" : 22.42594859241126,
        "shared_name" : "Synechocystis (interacts with) spK",
        "shared_interaction" : "interacts with",
        "name" : "Synechocystis (interacts with) spK",
        "interaction" : "interacts with",
        "SUID" : 231,
        "BEND_MAP_ID" : 73,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}